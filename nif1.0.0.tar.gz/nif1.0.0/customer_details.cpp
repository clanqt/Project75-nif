#include "customer_details.h"
#include "ui_customer_details.h"
#include <math.h>

#include <global.h>
using namespace Global;

Customer_Details::Customer_Details(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Customer_Details)
{
    ui->setupUi(this);

#if(NativeCompile)
    setParent(mdi,Qt::Dialog);
#endif

#if(SDK75)
    setParent(MdiArea,Qt::Dialog);
#endif
    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);


}

Customer_Details::~Customer_Details()
{
    delete ui;
}

void Customer_Details::keyPressEvent(QKeyEvent *ke)
{
    if(ke->key()== Qt::Key_Escape)
    {
        this->close();
        Home_ScreenObj->set_focus();
        Home_ScreenObj->show();
    }
}

void Customer_Details::call_Customer_Details()
{
    ui->lineEdit_Excess->clear();
    ui->lineEdit_paid->clear();

    ui->label_excess_title->hide();
    ui->label_excess_paid->hide();

    ui->label_balance_title->hide();
    ui->label_final_balance->hide();

    ui->label_count->clear();
    ui->label_est_amt->clear();
    ui->label_final_balance->clear();
    ui->label_Payable->clear();

    ui->label_previous_balance->clear();

    ui->label_unit_5->hide();
    ui->label_unit_8->hide();

//    select configuration_master.husk_per_cft,configuration_master.rate_of_cft,configuration_master.husk_per_bale,configuration_master.rate_of_husk from configuration_master

    if(Home_ScreenObj->selected_cus_balance_type.toInt() == 0)
    {
        ui->label_balance_type->setText("Op.Advance:");
    }

    if(Home_ScreenObj->selected_cus_balance_type.toInt() == 1)
    {
        ui->label_balance_type->setText("Op.Pending:");
    }


    qDebug()<<"test1 ===>>>";
    ui->label_previous_balance->setText(Home_ScreenObj->selected_cus_balance);
    qDebug()<<"test2 ===>>>"<<Home_ScreenObj->selected_cus_balance;

    ui->label_count->setText(Home_ScreenObj->final_count);
    qDebug()<<"test3 ===>>>"<<Home_ScreenObj->final_count;

    ui->label_est_amt->setText(Home_ScreenObj->estimated_amount);
    qDebug()<<"test4 ===>>>"<<Home_ScreenObj->estimated_amount;


    ui->lineEdit_Excess->installEventFilter(this);
    ui->lineEdit_paid->installEventFilter(this);



    ui->lineEdit_Excess->setFocus();
}

//bool Customer_Details::eventFilter(QObject *target, QEvent *event)
//{
//    QKeyEvent *key = static_cast <QKeyEvent*> (event);
//    if(target == ui->lineEdit_Excess)
//    {
////        if(event->type() == QEvent::FocusIn)
////        {
//////            g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
////            //            g_ccmainObj->setKeypadModeLock(false);
////            return true;
////        }
//    }
//    else if(target == ui->lineEdit_Excess)
//    {
//        if(event->type() == QEvent::FocusIn)
//        {
////            g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
//            //            g_ccmainObj->setKeypadModeLock(false);
//            return true;
//        }
//    }
//    else
//    {
//        return false;
//    }
//    return false;
//}

void Customer_Details::on_lineEdit_Excess_returnPressed()
{
    if(!ui->lineEdit_Excess->text().isEmpty())
    {

        qDebug()<<"Home_ScreenObj->selected_cus_balance_type ===>>>"<<Home_ScreenObj->selected_cus_balance_type;
        if(Home_ScreenObj->selected_cus_balance_type.toInt() == 0)
        {
            payable_amt = QString::number(ceil(ui->lineEdit_Excess->text().toFloat() - Home_ScreenObj->selected_cus_balance.toFloat()),'f',2);
            ui->label_Payable->setText(payable_amt);
            ui->lineEdit_paid->setFocus();

        }

        if(Home_ScreenObj->selected_cus_balance_type.toInt() == 1)
        {
            payable_amt = QString::number(ceil(ui->lineEdit_Excess->text().toFloat() + Home_ScreenObj->selected_cus_balance.toFloat()),'f',2);
            ui->label_Payable->setText(payable_amt);
            ui->lineEdit_paid->setFocus();
        }

        if(Home_ScreenObj->selected_cus_balance_type.toInt() == 2)
        {
            payable_amt = QString::number(ceil(ui->lineEdit_Excess->text().toFloat()),'f',2);
            ui->label_Payable->setText(payable_amt);
            ui->lineEdit_paid->setFocus();
        }
        float excess_calc = ui->lineEdit_Excess->text().toFloat() - Home_ScreenObj->estimated_amount.toFloat();
        if(excess_calc >= 0)
        {
            ui->label_excess_title->show();
            ui->label_excess_paid->show();
            ui->label_unit_5->show();
            ui->label_excess_paid->setText(QString::number(excess_calc,'f',2));
            ui->lineEdit_paid->setFocus();

        }





    }
}

void Customer_Details::on_lineEdit_paid_returnPressed()
{
    if(!ui->lineEdit_paid->text().isEmpty())
    {
        paid_amt = ui->lineEdit_paid->text();
        qDebug()<<"paid_amt payable_amt ===>>>"<<paid_amt<<payable_amt;
        if(payable_amt.toFloat() > paid_amt.toFloat())
        {
            qDebug()<<"balance 1 ===>>>";
            balance = QString::number(payable_amt.toFloat() - paid_amt.toFloat());
            balance_type = "1";

            ui->label_balance_title->show();
            ui->label_balance_title->setText("Pending    :");


            ui->label_final_balance->show();
            ui->label_unit_8->show();
            ui->label_final_balance->setText(balance);
        }
        else if(payable_amt.toFloat() < paid_amt.toFloat())
        {
            qDebug()<<"balance 2 ===>>>";
            balance = QString::number(paid_amt.toFloat() - payable_amt.toFloat());
            balance_type = "0";

            ui->label_balance_title->show();
            ui->label_balance_title->setText("Advance.Amt:");

            ui->label_final_balance->show();
            ui->label_unit_8->show();
            ui->label_final_balance->setText(balance);
        }
        else
        {
            qDebug()<<"balance 3 ===>>>";
            balance = QString::number(paid_amt.toFloat() - payable_amt.toFloat());
            balance_type = "2";
        }



        ui->pushButton_print->setFocus();
    }
}

void Customer_Details::on_pushButton_print_clicked()
{

    //! print


    QSqlQuery qry;
    if(databaseObj->selectQuery("select last_bill_no from configuration_master",qry))
    {
        if(qry.next())
        {
            if(qry.value(0).toString().trimmed().isEmpty())
            {
                gstrBillNo="00001";
                if(databaseObj->executeCommand("insert into configuration_master (last_bill_no) values ('00000')"))
                {
                    databaseObj->con.commit();
                }
            }
            else
                gstrBillNo=QString::number(qry.value(0).toInt() + 1).rightJustified(5,'0');
        }
        else{
            gstrBillNo="00001";
            if(databaseObj->executeCommand("insert into configuration_master (last_bill_no) values ('00000')"))
            {
                databaseObj->con.commit();
            }
        }
    }
    save_transaction();
    qDebug()<<"billno"<<gstrBillNo;



    #if(SDK75)
    CPrinter print;
    print.setFontType(CPrinter::eFontType_font2);
//    print.addData("New India Fiber",CPrinter::eFontSize_BIG,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
//    print.addData("New India Fiber",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);

    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("Receipt",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    print.addData(StringAlign("Receipt No.:",15)+gstrBillNo,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData(StringAlign("Date & Time:",15)+QDate::currentDate().toString("dd-MM-yyyy")+" "+QTime::currentTime().toString("hh:mm:ss"),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData(StringAlign("USER Name  :",15)+gstrUserName,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    if(Home_ScreenObj->selected_vehicle_type.toInt() == 0)
    {
        print.addData(StringAlign("Broker Name :",15)+Home_ScreenObj->selected_cus_name,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    }
    else
    {
        print.addData(StringAlign("Party Name :",15)+Home_ScreenObj->selected_cus_name,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    }
//    print.addData(StringAlign("Party Mob  :",15)+Home_ScreenObj->selected_cus_mobile,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    QString inward,uom,tot;
    if(Home_ScreenObj->inward_type == 0)
    {
        inward = "CFT  ";
        tot = Home_ScreenObj->total_cft;
        uom = "CFT";

    }
    if(Home_ScreenObj->inward_type == 1)
    {
        inward = "Count";
        tot = Home_ScreenObj->final_count;
        uom = "Nos";
    }


    print.addData(StringAlign("Vehicle No. :",15)+Home_ScreenObj->selected_vehicle_number,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData(StringAlign("Vehicle Type :",15)+Home_ScreenObj->selected_vehicle_type_name,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData(StringAlign("Inward Type:",15)+inward,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    if(Home_ScreenObj->inward_type == 0)
        print.addData(StringAlign("Total "+inward+" :",15)+Home_ScreenObj->selected_vehicle_length+"*"+Home_ScreenObj->selected_vehicle_width+"*"+Home_ScreenObj->selected_vehicle_height+" = "+Home_ScreenObj->total_cft+" "+uom,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    if(Home_ScreenObj->inward_type == 1)
        print.addData(StringAlign("Total "+inward+" :",15)+Home_ScreenObj->final_count+" "+uom,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


    print.addData(StringAlign(ui->label_balance_type->text(),15)+" Rs."+Home_ScreenObj->selected_cus_balance,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    print.addData(StringAlign("Numbers     :",15)+Home_ScreenObj->final_count+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    print.addData(StringAlign("Estimated.Amt:",15)+" Rs."+Home_ScreenObj->estimated_amount,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    print.addData(StringAlign("Approved.Amt:",15)+" Rs."+ui->lineEdit_Excess->text(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    if(payable_amt>0)
    {
        print.addData(StringAlign("Payable Amt :",15)+" Rs."+payable_amt,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    }
    print.addData(StringAlign("Paid Amount :",15)+" Rs."+paid_amt,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

//    print.addData(StringAlign("Balance    :",15)+" Rs."+balance,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

    qDebug()<<"ui->label_excess_paid->text() ===>>>"<<ui->label_excess_paid->text();

    float f1 = ui->label_excess_paid->text().toFloat();
    qDebug()<<"ui->label_excess_paid->text() to float ===>>>"<<QString::number(f1);
    if(f1 > 0)
    {
        qDebug()<<"ui->label_excess_paid->text() > 0===>>>";
        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData(StringAlign("Excess Amt  :",15)+" Rs."+ui->label_excess_paid->text(),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    }

    if(ui->label_balance_title->isVisible())
    {
        print.addData(StringAlign(ui->label_balance_title->text()+":",15)+" Rs."+ui->label_final_balance->text(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    }
    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("Thank You",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    if(print.print(true,false))
    {

    }





    #endif


//    g_ccmainObj->setKeypadModeLock(false);
    this->close();
    Home_ScreenObj->call_Home_Screen();
    Home_ScreenObj->show();
}

void Customer_Details::save_transaction()
{
    QString batch_type,inward_to,batch_number,odometer_name,odometer_value;
    if(Home_ScreenObj->selected_vehicle_type.toInt() == 0)
    {
        batch_type = "0";
        batch_number = gstrshift_no;
        inward_to = "company_batch_no";
        odometer_name = ",odometer_reading";


    }
    if(Home_ScreenObj->selected_vehicle_type.toInt() == 1)
    {
        batch_type = "1";
        batch_number = gstrshift_no_other;
        inward_to = "other_batch_no";
    }
    if(Home_ScreenObj->selected_vehicle_type.toInt() == 2)
    {
        batch_type = "2";
        batch_number = gstrshift_no_van;
        inward_to = "van_batch_no";
    }
    if(Home_ScreenObj->selected_vehicle_type.toInt() == 0)
    {
        if(databaseObj->executeCommand("insert into transaction_master (cus_id,cus_name,cus_mobile,vehicle_no,vehicle_height,inward_type,previous_balance,est_amt,excess_amt,payable,paid,balance,uploade_flag,day_no,batch_type,batch_no,bill_no,odometer_reading,inward_bale,inward_hush,vkms,balance_type,is_payment) values ('"+Home_ScreenObj->selected_cus_id+"','"+Home_ScreenObj->selected_cus_name+"','"+Home_ScreenObj->selected_cus_mobile+"','"+Home_ScreenObj->selected_vehicle_number+"','"+Home_ScreenObj->selected_vehicle_height+"','"+QString::number(Home_ScreenObj->inward_type)+"','"+Home_ScreenObj->selected_cus_balance+"','"+Home_ScreenObj->estimated_amount+"','"+QString::number(ui->label_excess_paid->text().toFloat(),'f',2)+"','"+payable_amt+"','"+paid_amt+"','"+balance+"','0','"+gstrday_no+"','"+Home_ScreenObj->selected_vehicle_type+"','"+batch_number+"','"+gstrBillNo+"','"+Home_ScreenObj->odometer_reading+"','"+Home_ScreenObj->total_cft+"','"+Home_ScreenObj->final_count+"',(select '"+Home_ScreenObj->odometer_reading+"'-sum(vehicle_registration.odometer_reading) from vehicle_registration where vehicle_registration.vehicle_no='"+Home_ScreenObj->selected_vehicle_number+"'),'"+balance_type+"','0')"))
        {
            qDebug()<<"save_transaction ===>>>"<<Home_ScreenObj->odometer_reading;
            if(databaseObj->executeCommand("update customer_master set balance='"+balance+"',balance_type='"+balance_type+"' where id_customer_master='"+Home_ScreenObj->selected_cus_id+"'"))
            {
                qDebug()<<"balance update success ===>>>"<<gstrBillNo;
            }

            if(databaseObj->executeCommand("update vehicle_registration set odometer_reading='"+Home_ScreenObj->odometer_reading+"' where vehicle_no='"+Home_ScreenObj->selected_vehicle_number+"'"))
            {
                qDebug()<<"vehicle_registration odometer_reading update success ===>>>"<<Home_ScreenObj->selected_vehicle_number<<Home_ScreenObj->odometer_reading;
            }


            if(databaseObj->executeCommand("update "+inward_to+" set inward_stock=(select "+inward_to+".inward_stock from "+inward_to+"  where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"')+'"+Home_ScreenObj->total_cft+"' where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"'"))
            {
                qDebug()<<"balance update success ===>>>"<<gstrBillNo;

                if(databaseObj->executeCommand("update "+inward_to+" set total_husk_produced=(select "+inward_to+".total_husk_produced from "+inward_to+"  where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"')+'"+Home_ScreenObj->final_count+"' where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"'"))
                {
                    qDebug()<<"total_husk_produced update success ===>>>";
                }

            }
            if(databaseObj->executeCommand("update configuration_master set last_bill_no='"+gstrBillNo+"'"))
            {
                qDebug()<<"bill_no update success ===>>>";
            }
//            if(databaseObj->executeCommand("update vehicle_registration set odometer_reading='"+Home_ScreenObj->odometer_reading+"' where vehi"))
//            {
//                qDebug()<<"odometer_reading update success ===>>>";
//            }
        }
    }
    else
    {

            if(databaseObj->executeCommand("insert into transaction_master (cus_id,cus_name,cus_mobile,vehicle_no,vehicle_height,inward_type,previous_balance,est_amt,excess_amt,payable,paid,balance,uploade_flag,day_no,batch_type,batch_no,bill_no,inward_bale,inward_hush,balance_type,is_payment) values ('"+Home_ScreenObj->selected_cus_id+"','"+Home_ScreenObj->selected_cus_name+"','"+Home_ScreenObj->selected_cus_mobile+"','"+Home_ScreenObj->selected_vehicle_number+"','"+Home_ScreenObj->selected_vehicle_height+"','"+QString::number(Home_ScreenObj->inward_type)+"','"+Home_ScreenObj->selected_cus_balance+"','"+Home_ScreenObj->estimated_amount+"','"+QString::number(ui->label_excess_paid->text().toFloat(),'f',2)+"','"+payable_amt+"','"+paid_amt+"','"+balance+"','0','"+gstrday_no+"','"+Home_ScreenObj->selected_vehicle_type+"','"+batch_number+"','"+gstrBillNo+"','"+Home_ScreenObj->total_cft+"','"+Home_ScreenObj->final_count+"','"+balance_type+"','0')"))
            {
                qDebug()<<"save_transaction ===>>>";
                if(databaseObj->executeCommand("update customer_master set balance='"+balance+"',balance_type='"+balance_type+"' where id_customer_master='"+Home_ScreenObj->selected_cus_id+"'"))
                {
                    qDebug()<<"balance update success ===>>>"<<gstrBillNo;
                }
                if(databaseObj->executeCommand("update "+inward_to+" set inward_stock=(select "+inward_to+".inward_stock from "+inward_to+"  where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"')+'"+Home_ScreenObj->total_cft+"' where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"'"))
                {
                    qDebug()<<"balance update success ===>>>"<<gstrBillNo;

                    if(databaseObj->executeCommand("update "+inward_to+" set total_husk_produced=(select "+inward_to+".total_husk_produced from "+inward_to+"  where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"')+'"+Home_ScreenObj->final_count+"' where batch_no='"+batch_number+"' and status='1' and day_no='"+gstrday_no+"'"))
                    {
                        qDebug()<<"total_husk_produced update success ===>>>";
                    }

                }
                if(databaseObj->executeCommand("update configuration_master set last_bill_no='"+gstrBillNo+"'"))
                {
                    qDebug()<<"bill_no update success ===>>>";
                }
            }

    }
}

QString Customer_Details::StringAlign(QString Data,int len)
{
    QString space = "";
    QString final;
    if(Data.length()<len){
        for(int i=Data.length();i < len ;i++)
            space=space+" ";
        final=Data+space;
    }
    else
    {
        Data.truncate(len);
        final=Data;
    }
    qDebug() << "alignsize" <<final.size();
    return final;
}


QString Customer_Details::StringRightAlign(QString Data,int len)
{
    QString space = "";
    for(int i=Data.length();i < len ;i++)
        space=" "+space;
    qDebug() << "rightlignsize" <<Data.size()+space.size();
    return space+Data;
}

void Customer_Details::on_lineEdit_Excess_textEdited(const QString &arg1)
{
    ui->label_excess_title->hide();
    ui->label_excess_paid->hide();
    ui->label_excess_paid->clear();
    ui->label_unit_5->hide();
}
