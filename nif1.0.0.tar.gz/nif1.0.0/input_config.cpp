#include "input_config.h"
#include "ui_input_config.h"

#include <QMessageBox>

#include <global.h>
using namespace Global;

Input_Config::Input_Config(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Input_Config)
{
    ui->setupUi(this);

#if(NativeCompile)
    setParent(mdi,Qt::Dialog);
#endif

#if(SDK75)
    setParent(MdiArea,Qt::Dialog);
#endif
    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);

}

Input_Config::~Input_Config()
{
    delete ui;
}

void Input_Config::call_Input_Config()
{
    ui->lineEdit_bull->clear();
    ui->lineEdit_cash->clear();
    ui->lineEdit_diesel->clear();
    ui->lineEdit_eb->clear();
    ui->lineEdit_generator->clear();
    ui->lineEdit_husk_per_bale->clear();
    ui->lineEdit_husk_per_cft->clear();

    ui->lineEdit_bull->installEventFilter(this);
    ui->lineEdit_cash->installEventFilter(this);
    ui->lineEdit_diesel->installEventFilter(this);
    ui->lineEdit_eb->installEventFilter(this);
    ui->lineEdit_generator->installEventFilter(this);
    ui->lineEdit_husk_per_bale->installEventFilter(this);
    ui->lineEdit_husk_per_cft->installEventFilter(this);

    ui->label_site_site_title->hide();
    ui->lineEdit_cash->hide();
    ui->label_unit_rs->hide();

    ui->pushButton_save->setEnabled(false);

    ui->lineEdit_husk_per_cft->setFocus();
}

void Input_Config::keyPressEvent(QKeyEvent *ke)
{
    if(ke->key()== Qt::Key_Escape)
    {
        this->close();
        menuObj->call_menu();
        menuObj->show();
    }
}

bool Input_Config::eventFilter(QObject *target, QEvent *event)
{
    QKeyEvent *key = static_cast <QKeyEvent*> (event);

    if(target == ui->lineEdit_husk_per_cft)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_husk_per_cft->hasFocus() && !ui->lineEdit_husk_per_cft->text().trimmed().isEmpty())
                {
                    ui->lineEdit_husk_per_bale->setFocus();
                }
            }
        }
    }
    else if(target == ui->lineEdit_husk_per_bale)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_husk_per_bale->hasFocus() && !ui->lineEdit_husk_per_bale->text().trimmed().isEmpty())
                {
                    ui->lineEdit_bull->setFocus();
                }
            }
        }
    }
    else if(target == ui->lineEdit_bull)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_bull->hasFocus() && !ui->lineEdit_bull->text().trimmed().isEmpty())
                {
                    ui->lineEdit_generator->setFocus();
                }
            }
        }
    }
    else if(target == ui->lineEdit_generator)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_generator->hasFocus() && !ui->lineEdit_generator->text().trimmed().isEmpty())
                {
                    ui->lineEdit_eb->setFocus();
                }
            }
        }
    }
    else if(target == ui->lineEdit_eb)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_eb->hasFocus() && !ui->lineEdit_eb->text().trimmed().isEmpty())
                {
                    ui->lineEdit_diesel->setFocus();
                }
            }
        }
    }
    else if(target == ui->lineEdit_diesel)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_diesel->hasFocus() && !ui->lineEdit_diesel->text().trimmed().isEmpty())
                {
                    ui->pushButton_save->setEnabled(true);
                    ui->pushButton_save->setFocus();
                }
            }
        }
    }
    else if(target == ui->lineEdit_cash)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_cash->hasFocus() && !ui->lineEdit_cash->text().trimmed().isEmpty() && !ui->lineEdit_eb->text().trimmed().isEmpty() && !ui->lineEdit_generator->text().trimmed().isEmpty() && !ui->lineEdit_bull->text().trimmed().isEmpty() && !ui->lineEdit_husk_per_bale->text().trimmed().isEmpty() && !ui->lineEdit_husk_per_cft->text().trimmed().isEmpty())
                {
                    ui->pushButton_save->setEnabled(true);
                    ui->pushButton_save->setFocus();
                }
            }
        }
    }
    else
    {
        return false;
    }

    return false;
}

void Input_Config::on_pushButton_save_clicked()
{
    if(databaseObj->executeCommand("update configuration_master set husk_per_cft='"+ui->lineEdit_husk_per_cft->text().trimmed()+"',husk_per_bale='"+ui->lineEdit_husk_per_bale->text().trimmed()+"',init_bull_reading='"+ui->lineEdit_bull->text().trimmed()+"',init_gen_reading='"+ui->lineEdit_generator->text().trimmed()+"',init_eb_reading='"+ui->lineEdit_eb->text().trimmed()+"',init_diesel_reading='"+ui->lineEdit_diesel->text().trimmed()+"'"))
    {
        qDebug()<<"initial configuration_master saved ===>>>";
#if(NativeCompile)
                QMessageBox gMsg_box;
                QFont gFont;
                gFont.setFamily("DejaVu Sans Mono");
                gFont.setPointSize(12);
                gMsg_box.setFont(gFont);
                gMsg_box.setParent(this);

                if(gMsg_box.information(this, "Success","Initiall Configuretion\nSaved Successfully..!",QMessageBox::Ok) == QMessageBox::Ok)
                {
                    this->close();
                    menuObj->call_menu();
                    menuObj->show();
                }
#endif

#if(SDK75)
                int ret = g_ccmainObj->messagebox(this,"Status",eMessageType_Success,"Initiall Configuretion\nSaved Successfully..!",16,14);
                this->close();
                menuObj->call_menu();
                menuObj->show();
#endif
    }
}
