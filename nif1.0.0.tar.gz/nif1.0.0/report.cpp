#include "report.h"
#include "ui_report.h"

#include <QMessageBox>
#include <QDebug>

#include <global.h>
using namespace Global;


Report::Report(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Report)
{
    ui->setupUi(this);

#if(NativeCompile)
    setParent(mdi,Qt::Dialog);
#endif

#if(SDK75)
    setParent(MdiArea,Qt::Dialog);
#endif
    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);


    scroll = new QScrollArea(ui->groupBox);
    scroll->setWidget(ui->verticalLayoutWidget);
    scroll->move(0,30);
    scroll->setFixedSize(320,150);//160
    scroll->setFocusPolicy(Qt::NoFocus);
    scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);


}

Report::~Report()
{
    delete ui;
}

void Report::keyPressEvent(QKeyEvent *ke)
{
    if(ke->key()== Qt::Key_Escape)
    {
        if(ui->groupBox->isVisible())
        {
            this->close();
            menuObj->call_menu();
            menuObj->show();
        }
        else
        {
            call_Report();
        }
    }
}

void Report::call_Report()
{

    ui->groupBox_batch_report->hide();
    ui->groupBox_batch_report->move(0,0);

    ui->groupBox_batch_supplier->hide();
    ui->groupBox_batch_supplier->move(0,0);

    ui->groupBox_supplier_report->hide();
    ui->groupBox_supplier_report->move(0,0);


    ui->groupBox_day_close->hide();
    ui->groupBox_day_close->move(0,0);


    //    ui->comboBox_batch->setEnabled(true);


    ui->label_purchase->clear();
    ui->label_husk_bale->clear();
    ui->label_bale->clear();
    ui->label_purchase->clear();
    ui->label_gain_lose->clear();
    ui->comboBox_batch->clear();

    ui->dateEdit_from->setDateTime(QDateTime::currentDateTime());
    ui->dateEdit_to->setDateTime(QDateTime::currentDateTime());

    ui->dateEdit_from_supplier->setDateTime(QDateTime::currentDateTime());
    ui->dateEdit_to_supplier->setDateTime(QDateTime::currentDateTime());

    ui->dateEdit_from->setCurrentSection(QDateEdit::DaySection);
    ui->dateEdit_to->setCurrentSection(QDateEdit::DaySection);

    ui->dateEdit_from->installEventFilter(this);
    ui->dateEdit_to->installEventFilter(this);

    ui->dateEdit_from_supplier->installEventFilter(this);
    ui->dateEdit_to_supplier->installEventFilter(this);

    ui->comboBox_batch->installEventFilter(this);
    ui->lineEdit_batch_supplier->installEventFilter(this);

    ui->groupBox->show();
    ui->pushButton_day_close->setFocus();
}

bool Report::eventFilter(QObject *target, QEvent *event)
{
    QKeyEvent *key = static_cast <QKeyEvent*> (event);

    if(target == ui->comboBox_batch)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->comboBox_batch->hasFocus() && !ui->comboBox_batch->currentText().isEmpty())
                {
                    ui->label_purchase->setText(lst_purchase.at(ui->comboBox_batch->currentIndex()));
                    ui->label_bale->setText(lst_bale.at(ui->comboBox_batch->currentIndex()));


                    float h_to_b = lst_husk.at(ui->comboBox_batch->currentIndex()).toFloat() / Home_ScreenObj->HP_bale.toFloat();
                    qDebug()<<"husk to bale ===>>>"<<QString::number(h_to_b,'f',2);

                    ui->label_husk_bale->setText(QString::number(h_to_b,'f',2));
                    qDebug()<<"husk to bale 1 ===>>>";
                    ui->label_gain_lose->setText(lst_gain_lose.at(ui->comboBox_batch->currentIndex()));
                    qDebug()<<"husk to bale 2 ===>>>";

                    return true;
                }
            }
        }

    }
    else if(target == ui->lineEdit_batch_supplier)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->lineEdit_batch_supplier->hasFocus() && !ui->lineEdit_batch_supplier->text().isEmpty())
                {

                    QSqlQuery batch_supplier_qur;

                    QString bat_type,bat_num;
                    //                        if(ui->lineEdit_batch_supplier->text().trimmed().contains())
                    if( ui->lineEdit_batch_supplier->text().trimmed().contains("company",Qt::CaseInsensitive))
                        bat_type = "0";
                    if( ui->lineEdit_batch_supplier->text().trimmed().contains("other",Qt::CaseInsensitive))
                        bat_type = "1";
                    if( ui->lineEdit_batch_supplier->text().trimmed().contains("van",Qt::CaseInsensitive))
                        bat_type = "2";

                    bat_num = QString::number(ui->lineEdit_batch_supplier->text().trimmed().split(" ").at(1).toInt());
                    qDebug()<<"bat_num ===>>>"<<bat_num;

                    if(databaseObj->selectQuery("select vehicle_no,cus_name,count(vehicle_no),sum(inward_bale),sum(inward_hush) from transaction_master where batch_no='"+bat_num+"' and batch_type='"+bat_type+"' group by cus_name",batch_supplier_qur))
                    {
                        if(batch_supplier_qur.next())
                        {

                            CPrinter print;
                            print.setFontType(CPrinter::eFontType_font2);

                            print.addData("Batch Supplier Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);

                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData(" Vehicle     Cust   L  CFT      Husk",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                            QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ', true)+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ', true)+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed().toFloat(),'f',2).rightJustified(6,' ', true)+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed().toFloat(),'f',2).rightJustified(9,' ', true);
                            qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                            print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            while(batch_supplier_qur.next())
                            {
                                QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ', true)+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ', true)+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed().toFloat(),'f',2).rightJustified(6,' ', true)+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed().toFloat(),'f',2).rightJustified(9,' ', true);
                                qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                                print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            }

                            batch_supplier_qur.clear();
                            if(databaseObj->selectQuery("select sum(inward_bale),sum(inward_hush) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",batch_supplier_qur))
                            {
                                if(batch_supplier_qur.next())
                                {
                                    print.addData("Total Husk: "+batch_supplier_qur.value(0).toString().trimmed()+"Nos",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                                }
                            }

                            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                            if(print.print(false,false))
                            {

                            }

                            ui->lineEdit_batch_supplier->clear();
                            ui->lineEdit_batch_supplier->setFocus();
                        }
                        else
                        {
#if(NativeCompile)
                            QMessageBox gMsg_box;
                            QFont gFont;
                            gFont.setFamily("DejaVu Sans Mono");
                            gFont.setPointSize(12);
                            gMsg_box.setFont(gFont);
                            gMsg_box.setParent(this);

                            if(gMsg_box.information(this, "Success","No Result\nFound..!",QMessageBox::Ok) == QMessageBox::Ok)
                            {
                                ui->dateEdit_to->setFocus();
                            }
#endif

#if(SDK75)
                            int ret = g_ccmainObj->messagebox(this,"Status",eMessageType_Critical,"No Result\nFound.",16,14);
                            g_ccmainObj->setKeypadMode(eKeypadMode_ALPHABETS);
                            ui->lineEdit_batch_supplier->selectAll();
#endif
                        }

                    }

                    return true;
                }
            }
        }

    }

    else if(target == ui->dateEdit_from_supplier)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->dateEdit_from_supplier->hasFocus())
                {
                    ui->dateEdit_to_supplier->setFocus();
                    ui->dateEdit_to_supplier->setDate(ui->dateEdit_to_supplier->date());
#if(SDK75)
                    g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
                    ui->dateEdit_to_supplier->setCurrentSection(QDateEdit::DaySection);

                    return true;
                }
            }
        }

    }
    else if(target == ui->dateEdit_to_supplier)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->dateEdit_to_supplier->hasFocus())
                {
                    //                    print_supplier_report();
#if(SDK75)
                    g_ccmainObj->setKeypadMode(eKeypadMode_ALPHABETS);
#endif
                    ui->lineEdit_supplier_vno->setFocus();
                    return true;
                }

            }
        }

    }
    else if(target == ui->dateEdit_from)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->dateEdit_from->hasFocus())
                {
                    ui->dateEdit_to->setFocus();
                    return true;
                }
            }
        }

    }
    else if(target == ui->dateEdit_to)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->dateEdit_to->hasFocus())
                {

                    QSqlQuery date_qur;
                    QStringList lst_day_no;

                    lst_batch_no.clear();
                    lst_purchase.clear();
                    lst_bale.clear();
                    lst_husk.clear();
                    lst_husk_bale.clear();
                    lst_gain_lose.clear();

                    if(databaseObj->selectQuery("select day_no from day_master  where open_date between '"+ui->dateEdit_from->date().toString("dd-MM-yyyy")+"' and '"+ui->dateEdit_to->date().toString("dd-MM-yyyy")+"' and status='0'",date_qur))
                    {
                        qDebug()<<"test ===>>>1";
                        if(date_qur.next())
                        {
                            qDebug()<<"test ===>>>1.0";
                            lst_day_no << date_qur.value(0).toString().trimmed();
                            while(date_qur.next())
                            {
                                qDebug()<<"test ===>>>1.1";
                                lst_day_no << date_qur.value(0).toString().trimmed();
                            }
                            qDebug()<<"test ===>>>1.2"<<lst_day_no;

                        }
                        qDebug()<<"test ===>>>2";
                        if(lst_day_no.size() > 0)
                        {
                            qDebug()<<"test ===>>>2.1";
                            QStringList lst_batch;
                            lst_batch << "company_batch_no" << "other_batch_no" << "van_batch_no";
                            qDebug()<<"test ===>>>2.1";

                            for(int i=0;i<lst_batch.size();i++)
                            {
                                qDebug()<<"test ===>>>3";
                                //! batch close
                                for(int d=0;d<lst_day_no.size();d++)
                                {
                                    qDebug()<<"test ===>>>4"<<lst_day_no;
                                    QSqlQuery batch_day_qur;
                                    if(databaseObj->selectQuery("select * from "+lst_batch.at(i)+" where day_no_close='"+lst_day_no.at(d)+"' and production_status='0'",batch_day_qur))
                                    {
                                        qDebug()<<"test ===>>>4.1";
                                        if(batch_day_qur.next())
                                        {
                                            qDebug()<<"test ===>>>4.2";
                                            QString batch_name;
                                            if(lst_batch.at(i).contains("company",Qt::CaseInsensitive))
                                                batch_name = "Company ";
                                            if(lst_batch.at(i).contains("other",Qt::CaseInsensitive))
                                                batch_name = "Auto ";
                                            if(lst_batch.at(i).contains("van",Qt::CaseInsensitive))
                                                batch_name = "Van ";

                                            qDebug()<<"test ===>>>4.3";
                                            lst_batch_no << batch_name+batch_day_qur.value(0).toString().trimmed().rightJustified(3,'0');
                                            lst_purchase << batch_day_qur.value(9).toString().trimmed();
                                            lst_bale << batch_day_qur.value(3).toString().trimmed();
                                            lst_husk_bale << batch_day_qur.value(11).toString().trimmed();
                                            QString gl = batch_day_qur.value(12).toString().trimmed();
                                            qDebug()<<"gain r lose ===>>>"<<gl;
                                            if(gl.contains("-"))
                                            {
                                                lst_gain_lose << "Gain";
                                            }
                                            else{
                                                lst_gain_lose << "Lose";
                                            }

                                            while(batch_day_qur.next())
                                            {
                                                QString batch_name;
                                                if(lst_batch.at(d).contains("company",Qt::CaseInsensitive))
                                                    batch_name = "Company ";
                                                if(lst_batch.at(d).contains("other",Qt::CaseInsensitive))
                                                    batch_name = "Auto ";
                                                if(lst_batch.at(d).contains("van",Qt::CaseInsensitive))
                                                    batch_name = "Van ";

                                                lst_batch_no << batch_name+batch_day_qur.value(0).toString().trimmed().rightJustified(3,'0');
                                                lst_purchase << batch_day_qur.value(9).toString().trimmed();
                                                lst_bale << batch_day_qur.value(3).toString().trimmed();
                                                lst_husk_bale << batch_day_qur.value(11).toString().trimmed();

                                                QString gl = batch_day_qur.value(12).toString().trimmed();
                                                qDebug()<<"gain r lose ===>>>"<<gl;
                                                if(gl.contains("-"))
                                                {
                                                    lst_gain_lose << "Gain";
                                                }
                                                else{
                                                    lst_gain_lose << "Lose";
                                                }
                                            }
                                            qDebug()<<"test ===>>>4.4";
                                            qDebug()<<"lst_batch_no ===>>>"<<lst_batch_no;
                                            qDebug()<<"lst_purchase ===>>>"<<lst_purchase;
                                            qDebug()<<"lst_bale ===>>>"<<lst_bale;
                                            qDebug()<<"lst_husk_bale ===>>>"<<lst_husk_bale;
                                            qDebug()<<"lst_gain_lose ===>>>"<<lst_gain_lose;

                                        }
                                    }
                                }
                            }
                            ui->comboBox_batch->clear();
                            if(lst_batch_no.size() > 0)
                            {
                                qDebug()<<"test ===>>>5";
                                ui->comboBox_batch->addItems(lst_batch_no);
                                ui->comboBox_batch->setCurrentIndex(0);
                                qDebug()<<"test ===>>>5.1";
                            }
                            qDebug()<<"test ===>>>6";


                            //!
                        }
                        else
                        {
#if(NativeCompile)
                            QMessageBox gMsg_box;
                            QFont gFont;
                            gFont.setFamily("DejaVu Sans Mono");
                            gFont.setPointSize(12);
                            gMsg_box.setFont(gFont);
                            gMsg_box.setParent(this);

                            if(gMsg_box.information(this, "Success","No Result\nFound..!",QMessageBox::Ok) == QMessageBox::Ok)
                            {
                                ui->dateEdit_to->setFocus();
                            }
#endif

#if(SDK75)
                            int ret = g_ccmainObj->messagebox(this,"Status",eMessageType_Critical,"No Result\nFound.",16,14);
                            ui->dateEdit_to->setFocus();
#endif
                        }
                    }

                    ui->comboBox_batch->setFocus();
                    return true;
                }
            }
        }

    }
    else
    {
        return false;
    }
    return false;
}

void Report::on_pushButton_day_close_clicked()
{
    QSqlQuery day_qur;
    if(databaseObj->selectQuery("select day_no from day_master where status='0'",day_qur))
    {
//        QStringList lst_day_close_no;
        if(day_qur.next())
        {
            lst_day_close_no << "Day "+day_qur.value(0).toString().trimmed().rightJustified(3,'0');
            while(day_qur.next())
            {
                lst_day_close_no << "Day "+day_qur.value(0).toString().trimmed().rightJustified(3,'0');
            }
            cmpte5 = new QCompleter(lst_day_close_no,this);
            cmpte5->setCaseSensitivity(Qt::CaseInsensitive);
            cmpte5->setCompletionMode(QCompleter::PopupCompletion);
            ui->lineEdit_day_no->setCompleter(cmpte5);

            ui->groupBox->hide();

            ui->groupBox_day_close->show();
            ui->groupBox_day_close->raise();

            ui->lineEdit_day_no->setFocus();
        }
    }
}

void Report::day_close_report()
{
#if(SDK75)
    QSqlQuery day_details;
    if(databaseObj->selectQuery("SELECT day_no,status,open_date,open_time,close_date,close_time,open_bull_reading,open_gen_reading,open_eb_reading,open_diesel_reading,opening_bale_balance FROM day_master WHERE id_day= (SELECT MAX(id_day) FROM day_master where status='0')",day_details))
    {
        //#if(SDK75)
        if(day_details.next())
        {
            CPrinter print;
            print.setFontType(CPrinter::eFontType_font2);

            print.addData("Day Close Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);

            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Day No    :"+day_details.value(0).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Open Date :"+day_details.value(2).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Open Time :"+day_details.value(3).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Close Date:"+day_details.value(4).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Close Time:"+day_details.value(5).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

            day_details.clear();
            QStringList lst_aval_batch_type;
            QString total_husk;
            if(databaseObj->selectQuery("select transaction_master.batch_type from transaction_master where transaction_master.day_no=(SELECT day_no FROM day_master WHERE id_day=(SELECT MAX(id_day) FROM day_master where status='0')) group by transaction_master.batch_type",day_details))
            {
                if(day_details.next())
                {
                    lst_aval_batch_type << day_details.value(0).toString().trimmed();
                    while(day_details.next())
                    {
                        lst_aval_batch_type << day_details.value(0).toString().trimmed();
                    }
                    qDebug()<<"avaliable batched ===>>>"<<lst_aval_batch_type;
                }
            }
            if(lst_aval_batch_type.size() > 0)
            {
                print.addData("Purchase Details",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("SNO  Vh   Load  CFT    HUSK    EXCESS",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                float tmp_total = 0;
                print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                for(int i=0;i<lst_aval_batch_type.size();i++)
                {
                    day_details.clear();
                    if(databaseObj->selectQuery("select count(transaction_master.batch_type),sum(transaction_master.inward_bale),sum(transaction_master.inward_hush),sum(transaction_master.excess_amt),sum(transaction_master.inward_hush)*(select configuration_master.auto_rate_of_husk from configuration_master),sum(transaction_master.vkms) from transaction_master where transaction_master.batch_type='"+lst_aval_batch_type.at(i)+"'",day_details))
                    {
                        if(day_details.next())
                        {
                            QString batch_name,to_print;
                            if(lst_aval_batch_type.at(i).toInt() == 0)
                                batch_name = "Comp";
                            if(lst_aval_batch_type.at(i).toInt() == 1)
                                batch_name = "Auto";
                            if(lst_aval_batch_type.at(i).toInt() == 2)
                                batch_name = "Van ";

                            to_print = QString::number(i+1).rightJustified(3,'0')+" "+batch_name+" "+day_details.value(0).toString().trimmed().rightJustified(4,' ')+" "+day_details.value(1).toString().trimmed().rightJustified(4,' ')+" "+day_details.value(3).toString().trimmed().rightJustified(6,' ')+" "+day_details.value(4).toString().trimmed().rightJustified(7,' ')+" "+QString::number(day_details.value(5).toString().trimmed().toFloat(),'f',2).rightJustified(9,' ');
//                            to_print = QString::number(i+1).rightJustified(3,'0')+batch_name
                            tmp_total+=day_details.value(2).toString().trimmed().toFloat();

                            qDebug()<<"tmp_total ===>>>"<<tmp_total;
                            qDebug()<<"to_print ===>>>"<<to_print;

                            print.addData(to_print,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        }
                    }
                }

                float total_husk = tmp_total;
                print.addData("Husk Purchased: "+QString::number(tmp_total,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);

                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Cash Flow",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                print.addData("SNO  vh     Qty   Rate    Amt    Kms ",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                tmp_total = 0;
                for(int i=0;i<lst_aval_batch_type.size();i++)
                {

                    QString rate_of_husk;
                    day_details.clear();
                    if(databaseObj->selectQuery("select count(transaction_master.batch_type),sum(transaction_master.inward_bale),sum(transaction_master.inward_hush),sum(transaction_master.excess_amt),sum(transaction_master.inward_hush)*(select configuration_master.auto_rate_of_husk from configuration_master),sum(transaction_master.vkms) from transaction_master where transaction_master.batch_type='"+lst_aval_batch_type.at(i)+"'",day_details))
                    {
                        if(day_details.next())
                        {
                            QString batch_name,to_print,batch_name_rate;
                            if(lst_aval_batch_type.at(i).toInt() == 0){
                                batch_name = "Comp";
                                batch_name_rate = "rate_of_husk";
                            }
                            if(lst_aval_batch_type.at(i).toInt() == 1){
                                batch_name = "Auto";
                                batch_name_rate = "auto_rate_of_husk";
                            }
                            if(lst_aval_batch_type.at(i).toInt() == 2){
                                batch_name = "Van";
                                batch_name_rate = "van_rate_of_husk";
                            }

                            QSqlQuery husk_rate;
                            if(databaseObj->selectQuery("select configuration_master."+batch_name_rate+" from configuration_master",husk_rate))
                            {
                                if(husk_rate.next())
                                {
                                    rate_of_husk = husk_rate.value(0).toString().trimmed();
                                }
                            }

                            to_print = QString::number(i).rightJustified(3,'0')+" "+batch_name+" "+day_details.value(3).toString().trimmed().rightJustified(6,' ')+" "+rate_of_husk+" "+day_details.value(4).toString().trimmed().rightJustified(9,' ');
                            tmp_total+=day_details.value(4).toString().trimmed().toFloat();

                            qDebug()<<"tmp_total ===>>>"<<tmp_total;
                            qDebug()<<"to_print ===>>>"<<to_print;

                            print.addData(to_print,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                        }
                    }
                }
                float total_husk_amount = tmp_total;
                print.addData("Total Cash   : "+QString::number(tmp_total,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("Avg Hush Rate: "+QString::number(total_husk_amount/total_husk,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);



                QSqlQuery expense_qur;
                QStringList lst_expense_name,lst_expense_bill_no,lst_expense_amount,lst_expense_user_id;
                if(databaseObj->selectQuery("select * from expense_transaction where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",expense_qur))
                {
                    if(expense_qur.next())
                    {
                        lst_expense_name << expense_qur.value(2).toString().trimmed();
                        lst_expense_bill_no << expense_qur.value(3).toString().trimmed();
                        lst_expense_amount << expense_qur.value(4).toString().trimmed();
                        lst_expense_user_id << expense_qur.value(6).toString().trimmed();
                        while(expense_qur.next())
                        {
                            lst_expense_name << expense_qur.value(2).toString().trimmed();
                            lst_expense_bill_no << expense_qur.value(3).toString().trimmed();
                            lst_expense_amount << expense_qur.value(4).toString().trimmed();
                            lst_expense_user_id << expense_qur.value(6).toString().trimmed();
                        }
                    }
                }

                if(lst_expense_name.size() > 0)
                {
                    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                    print.addData("Expense",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                    print.addData("SNO      Expense Name        Amount",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                    float total_exp_amt = 0;
                    for(int i=0;i<lst_expense_name.size();i++)
                    {
                        QString prt_text = QString::number(i+1).rightJustified(2,' ')+" "+lst_expense_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_expense_amount.at(i).toFloat(),'f',2).rightJustified(15,' ');
                        qDebug()<<"expense data ===>>>"<<prt_text;
                        print.addData(prt_text,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        total_exp_amt += lst_expense_amount.at(i).toFloat();
                    }
                    print.addData("Total Expense: "+QString::number(total_exp_amt,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                }


                QSqlQuery husk_stock;
                //! auto batch

                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Stock Status Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                husk_stock.clear();
                if(databaseObj->selectQuery("select * from production_batch_order where batch_type='auto'",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        print.addData("Auto Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        while(husk_stock.next())
                        {
                            print.addData("Auto Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                    }
                }

                husk_stock.clear();
                if(databaseObj->selectQuery("select * from production_batch_order where batch_type='company'",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        print.addData("Company Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        while(husk_stock.next())
                        {
                            print.addData("Company Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                    }
                }

                husk_stock.clear();
                if(databaseObj->selectQuery("select * from production_batch_order where batch_type='van'",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        print.addData("Van Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        while(husk_stock.next())
                        {
                            print.addData("Van Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                    }
                }
                QString husk_available_production;
                husk_stock.clear();
                if(databaseObj->selectQuery("select sum(husk_available) from production_batch_order",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        husk_available_production = husk_stock.value(0).toString().trimmed();
                        //                        print.addData("Auto Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                    }
                }

                husk_stock.clear();
                QString closing_bale,closing_husk;
                if(databaseObj->selectQuery("select closing_bale_balance from day_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        closing_bale = husk_stock.value(0).toString().trimmed();
                        closing_husk = QString::number(closing_bale.toFloat()*Home_ScreenObj->HP_bale.toFloat(),'f',2);
                    }
                }

                float total_husk_count = husk_available_production.toFloat()+closing_husk.toFloat();

                print.addData("Total No Of Husk: "+QString::number(total_husk_count,'f',2)+" Nos",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);



                QSqlQuery diesel_qur;

                QString initial_diesel_stock;
                diesel_qur.clear();
                if(databaseObj->selectQuery("select init_diesel_reading from configuration_master",diesel_qur))
                {
                    if(diesel_qur.next())
                    {
                        initial_diesel_stock = diesel_qur.value(0).toString().trimmed();
                    }
                }
                diesel_qur.clear();
                if(databaseObj->selectQuery("select * from diesel_usage where day_no=(SELECT MAX(id_day) FROM day_master where status='0') and fill_type='1'",diesel_qur))
                {
                    if(diesel_qur.next())
                    {
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        print.addData("Diesel Consumption",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        diesel_qur.clear();
                        if(databaseObj->selectQuery("select * from diesel_usage where day_no=(SELECT MAX(id_day) FROM day_master where status='0') and fill_type='1' group by vehicle_no",diesel_qur))
                        {
                            if(diesel_qur.next())
                            {
                                QString v_name = diesel_qur.value(1).toString().trimmed();
                                QString diff = get_difference(v_name);
                                qDebug()<<"diff ===>>>"<<diff;
                                if(diff.toInt() > 0)
                                {
                                    print.addData(v_name.toUpper().leftJustified(12,' ')+": "+diff ,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                                }
                            }
                        }

                        print.addData("Closing Stock: "+initial_diesel_stock+" lts",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        diesel_qur.clear();
                    }
                }


                QSqlQuery payables_qur;
                QString v_pay = "0";
                QStringList lst_v_no,lst_party_name,lst_amt;
                payables_qur.clear();
                if(databaseObj->selectQuery("select vehicle_no,cus_name,paid from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",payables_qur))
                {
                    if(payables_qur.next())
                    {
                        lst_v_no << payables_qur.value(0).toString().trimmed();
                        lst_party_name << payables_qur.value(1).toString().trimmed();
                        lst_amt << payables_qur.value(2).toString().trimmed();
                        while(payables_qur.next())
                        {
                            lst_v_no << payables_qur.value(0).toString().trimmed();
                            lst_party_name << payables_qur.value(1).toString().trimmed();
                            lst_amt << payables_qur.value(2).toString().trimmed();
                        }
                    }
                    if(lst_v_no.size() > 0)
                    {
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        print.addData("Vehicle No    Party Name       Amount",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        for(int i=0;i<lst_v_no.size();i++)
                        {
                            print.addData(lst_v_no.at(i).leftJustified(11,' ')+" "+lst_party_name.at(i).rightJustified(15,' ')+" "+QString::number(lst_amt.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                        payables_qur.clear();
                        if(databaseObj->selectQuery("select sum(paid) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",payables_qur))
                        {
                            if(payables_qur.next())
                            {
                                v_pay = payables_qur.value(0).toString().trimmed();
                            }
                        }
                    }
                }

                QSqlQuery bunk_qur;
                QString bunk_pay = "0";
                QStringList lst_bunk_name,lst_bunk_qty,lst_bunk_amount;
                if(databaseObj->selectQuery("select diesel_transaction.bunk_id,bunk_master.bunk_name,diesel_transaction.quantity,diesel_transaction.amount from diesel_transaction inner join bunk_master on diesel_transaction.bunk_id=bunk_master.id_bunk_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",bunk_qur))
                {
                    if(bunk_qur.next())
                    {
                        lst_bunk_name << bunk_qur.value(1).toString().trimmed();
                        lst_bunk_qty << bunk_qur.value(2).toString().trimmed();
                        lst_bunk_amount << bunk_qur.value(3).toString().trimmed();
                        while(bunk_qur.next())
                        {
                            lst_bunk_name << bunk_qur.value(1).toString().trimmed();
                            lst_bunk_qty << bunk_qur.value(2).toString().trimmed();
                            lst_bunk_amount << bunk_qur.value(3).toString().trimmed();
                        }
                    }


                    if(lst_bunk_name.size() > 0)
                    {

                        if(lst_v_no.size() == 0)
                        {
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }

                        for(int i=0;i<lst_bunk_name.size();i++)
                        {
                            print.addData("            "+lst_bunk_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_bunk_amount.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                        bunk_qur.clear();
                        if(databaseObj->selectQuery("select sum(diesel_transaction.amount) from diesel_transaction where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",bunk_qur))
                        {
                            if(bunk_qur.next())
                            {
                                bunk_pay = bunk_qur.value(0).toString().trimmed();
                            }
                        }
                    }
                }

                QSqlQuery emp_qur;
                QString emp_pay = "0";
                QStringList lst_emp_name,lst_emp_amount;
                if(databaseObj->selectQuery("select emp_name,paid_salary from employee_transaction where paid_salary IS NOT NULL and day_no=(SELECT MAX(id_day) FROM day_master where status='0')",emp_qur))
                {
                    if(emp_qur.next())
                    {
                        lst_emp_name << emp_qur.value(0).toString().trimmed();
                        lst_emp_amount << emp_qur.value(1).toString().trimmed();
                        while(emp_qur.next())
                        {
                            lst_emp_name << emp_qur.value(0).toString().trimmed();
                            lst_emp_amount << emp_qur.value(1).toString().trimmed();
                        }
                    }
                    if(lst_emp_name.size() > 0)
                    {

                        if( (lst_v_no.size() == 0) && (lst_bunk_name.size() == 0) )
                        {
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }

                        for(int i=0;i<lst_emp_name.size();i++)
                        {
                            print.addData("            "+lst_emp_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_emp_amount.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                        emp_qur.clear();
                        if(databaseObj->selectQuery("select sum(paid_salary) from employee_transaction where paid_salary IS NOT NULL and day_no=(SELECT MAX(id_day) FROM day_master where status='0')",emp_qur))
                        {
                            if(emp_qur.next())
                            {
                                emp_pay = emp_qur.value(0).toString().trimmed();
                            }
                        }
                    }
                }
                if( (lst_v_no.size() != 0) || (lst_bunk_name.size() != 0) || (lst_emp_name.size() != 0) )
                {
                    print.addData("Total Payables:Rs "+QString::number(v_pay.toFloat() + emp_pay.toFloat() + bunk_pay.toFloat(),'f',2 ),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                }

                //                QSqlQuery batch_supplier_qur;
                //                if(databaseObj->selectQuery("select vehicle_no,cus_name,count(vehicle_no),sum(inward_bale),sum(inward_hush) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0') group by cus_name",batch_supplier_qur))
                //                {
                //                    if(batch_supplier_qur.next())
                //                    {
                //                        QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ')+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ')+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed(),'f',2).rightJustified(6,' ')+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed(),'f',2).rightJustified(9,' ');
                //                        qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                //                        print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                //                        while(batch_supplier_qur.next())
                //                        {
                //                            QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ')+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ')+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed(),'f',2).rightJustified(6,' ')+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed(),'f',2).rightJustified(9,' ');
                //                            qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                //                            print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                //                        }
                //                        batch_supplier_qur.clear();
                //                        if(databaseObj->selectQuery("select sum(inward_bale),sum(inward_hush) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",batch_supplier_qur))
                //                        {
                //                            if(batch_supplier_qur.next())
                //                            {
                ////                                QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ')+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ')+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed(),'f',2).rightJustified(6,' ')+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed(),'f',2).rightJustified(9,' ');
                ////                                qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                //                                print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                //                            }
                //                        }
                //                    }
                //                }



            }

            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            if(print.print(false,false))
            {

            }

        }
    }
#endif
}


QString Report::get_difference(QString name)
{
    QSqlQuery diesel_qur;
    if(databaseObj->selectQuery("SELECT count(*) FROM diesel_usage where vehicle_no='"+name+"' and fill_type='1' ORDER BY vehicle_no DESC limit 2",diesel_qur))
    {
        if(diesel_qur.next())
        {
            int count = diesel_qur.value(0).toString().toInt();
            qDebug()<<"count ===>>>"<<QString::number(count);
            if(count == 2)
            {
                diesel_qur.clear();
                if(databaseObj->selectQuery("SELECT reading FROM diesel_usage where vehicle_no='"+name+"' and fill_type='1' ORDER BY vehicle_no DESC limit 2",diesel_qur))
                {
                    QString val1,val2;
                    if(diesel_qur.next())
                    {
                        val1 = diesel_qur.value(0).toString().trimmed();
                        while(diesel_qur.next())
                        {
                            val2 = diesel_qur.value(0).toString().trimmed();
                        }
                        QString reading = QString::number(val1.toFloat()-val2.toFloat(),'f',2);
                        qDebug()<<"reading ===>>>"<<reading;
                        return reading;

                    }
                }
            }
            else
                return "";

        }
        else
            return "";
    }
    else
        return "";

}

void Report::on_pushButton_batch_close_clicked()
{
    ui->groupBox->hide();


    ui->dateEdit_from->setDateTime(QDateTime::currentDateTime());
    ui->dateEdit_from->setCurrentSection(QDateEdit::DaySection);
    //    ui->dateEdit_to->setDateTime(QDateTime::currentDateTime());
    //    ui->dateEdit_to->setCurrentSection(QDateEdit::DaySection);

    ui->groupBox_batch_report->show();
    ui->groupBox_batch_report->raise();

    ui->dateEdit_from->setFocus();
}

//void Report::on_comboBox_batch_currentIndexChanged(int index)
//{

////    qDebug()<<"on_comboBox_batch_currentIndexChanged ===>>>";
////    ui->label_purchase->clear();
////    ui->label_husk_bale->clear();
////    ui->label_bale->clear();
////    ui->label_purchase->clear();
////    ui->label_gain_lose->clear();

//    //    if(lst_batch_no.size() > 0)
//    //    {

//    //    }
//}

void Report::on_pushButton_supplier_batch_wise_clicked()
{
    ui->lineEdit_batch_supplier->clear();
    QSqlQuery batch_supplier_qur;


    QStringList lst_batch;
    lst_batch << "company_batch_no" << "other_batch_no" << "van_batch_no";
    qDebug()<<"test ===>>>2.1";

    lst_batch_no.clear();
    for(int i=0;i<lst_batch.size();i++)
    {

        QString batch_name;
        if(lst_batch.at(i).contains("company",Qt::CaseInsensitive))
            batch_name = "Company ";
        if(lst_batch.at(i).contains("other",Qt::CaseInsensitive))
            batch_name = "Auto ";
        if(lst_batch.at(i).contains("van",Qt::CaseInsensitive))
            batch_name = "Van ";


        if(databaseObj->selectQuery("select batch_no from "+lst_batch.at(i)+" order by batch_no desc",batch_supplier_qur))
        {
            if(batch_supplier_qur.next())
            {
                lst_batch_no << batch_name+batch_supplier_qur.value(0).toString().trimmed().rightJustified(3,'0');
                while(batch_supplier_qur.next())
                {
                    lst_batch_no << batch_name+batch_supplier_qur.value(0).toString().trimmed().rightJustified(3,'0');
                }
            }
        }
    }
    if(lst_batch_no.size() > 0)
    {

        cmpter = new QCompleter(lst_batch_no,this);
        cmpter->setCaseSensitivity(Qt::CaseInsensitive);
        cmpter->setCompletionMode(QCompleter::PopupCompletion);
        ui->lineEdit_batch_supplier->setCompleter(cmpter);
    }


    ui->groupBox->hide();
    ui->groupBox_batch_supplier->show();
    ui->groupBox_batch_supplier->raise();
#if(SDK75)
    g_ccmainObj->setKeypadMode(eKeypadMode_ALPHABETS);
#endif
    ui->lineEdit_batch_supplier->setFocus();

}

void Report::on_pushButton_supplier_clicked()
{
    ui->lineEdit_supplier_name->clear();
    ui->lineEdit_supplier_vno->clear();

    ui->label_name_balance_title->clear();
    ui->label_name_balance_amt->clear();

    QSqlQuery vehicle_details;
    if(databaseObj->selectQuery("select * from vehicle_registration",vehicle_details))
    {
        lst_vehicle_number.clear();
        if(vehicle_details.next())
        {
            lst_vehicle_number << vehicle_details.value(1).toString().trimmed();
        }
        while(vehicle_details.next())
        {
            lst_vehicle_number << vehicle_details.value(1).toString().trimmed();
        }
    }
    qDebug()<<"lst_vehicle_number ===>>>"<<lst_vehicle_number;

    cmpte3 = new QCompleter(lst_vehicle_number,this);
    cmpte3->setCaseSensitivity(Qt::CaseInsensitive);
    cmpte3->setCompletionMode(QCompleter::PopupCompletion);
    ui->lineEdit_supplier_vno->setCompleter(cmpte3);

    QSqlQuery broker_details;
    lst_broker_name.clear();
    lst_broker_mobile.clear();
    if(databaseObj->selectQuery("select * from customer_master where cus_type='1'",broker_details))
    {
        if(broker_details.next())
        {
            lst_broker_name << broker_details.value(1).toString().trimmed();
            lst_broker_mobile << broker_details.value(2).toString().trimmed();
        }
        while(broker_details.next())
        {
            lst_broker_name << broker_details.value(1).toString().trimmed();
            lst_broker_mobile << broker_details.value(2).toString().trimmed();
        }
    }

    cmpte4 = new QCompleter(lst_broker_name,this);
    cmpte4->setCaseSensitivity(Qt::CaseInsensitive);
    cmpte4->setCompletionMode(QCompleter::PopupCompletion);
    ui->lineEdit_supplier_name->setCompleter(cmpte4);


    ui->label_name->hide();
    ui->lineEdit_supplier_name->hide();

    ui->groupBox->hide();

    ui->groupBox_supplier_report->show();
    ui->groupBox_supplier_report->raise();

#if(SDK75)
    g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif

    ui->dateEdit_from_supplier->setFocus();



}

void Report::on_lineEdit_supplier_vno_returnPressed()
{
    if(!ui->lineEdit_supplier_vno->text().isEmpty())
    {
        QSqlQuery query;
        if(databaseObj->selectQuery("select * from vehicle_registration where vehicle_registration.vehicle_no='"+ui->lineEdit_supplier_vno->text().trimmed()+"'",query))
        {
            if(query.next())
            {
                selected_vehicle_number_id = query.value(0).toString().trimmed();
                selected_vehicle_number = query.value(1).toString().trimmed();
                selected_vehicle_name = query.value(2).toString().trimmed();

                selected_vehicle_length = query.value(3).toString().trimmed();
                selected_vehicle_length_inch = query.value(4).toString().trimmed();
                selected_vehicle_width = query.value(5).toString().trimmed();
                selected_vehicle_width_inch = query.value(6).toString().trimmed();
                selected_vehicle_type = query.value(7).toString().trimmed();

                ui->lineEdit_supplier_name->show();
                ui->label_name->show();

                if(selected_vehicle_type.toInt() == 0)
                {
                    ui->lineEdit_supplier_name->setReadOnly(false);
                    ui->label_name->setText("Broker    :");
                    ui->lineEdit_supplier_name->setFocus();
                    return;
                }

                ui->label_name->setText("Name      :");
                query.clear();
                if(databaseObj->selectQuery("select * from customer_master where id_vehicle_registration='"+selected_vehicle_number_id+"'",query))
                {
                    if(query.next())
                    {
                        selected_cus_id = query.value(0).toString().trimmed();
                        selected_cus_name = query.value(1).toString().trimmed();
                        selected_cus_mobile = query.value(2).toString().trimmed();
                        selected_cus_balance = query.value(3).toString().trimmed();
                        selected_cus_balance_type = query.value(4).toString().trimmed();

                        ui->label_name_balance_amt->setText("Rs "+selected_cus_balance);

                        ui->lineEdit_supplier_name->setText(selected_cus_name);
                        ui->lineEdit_supplier_name->setReadOnly(true);
                        ui->label_name_balance_title->show();
                        if(selected_cus_balance_type.toInt() == 0 || selected_cus_balance_type.toInt() == 2)
                        {
                            ui->label_name_balance_title->setText("Op.Advance:");
                        }

                        if(selected_cus_balance_type.toInt() == 1)
                        {
                            ui->label_name_balance_title->setText("Op.Pending:");
                        }

                        qApp->processEvents();
                        qApp->processEvents();
                        print_supplier_report();


                    }
                }

            }
        }
    }
}

void Report::on_lineEdit_supplier_name_returnPressed()
{
    if(!ui->lineEdit_supplier_name->text().isEmpty())
    {
        QSqlQuery query;
        if(databaseObj->selectQuery("select * from customer_master where cus_name='"+ui->lineEdit_supplier_name->text().trimmed()+"'",query))
        {
            if(query.next())
            {
                selected_cus_id = query.value(0).toString().trimmed();
                selected_cus_name = query.value(1).toString().trimmed();
                selected_cus_mobile = query.value(2).toString().trimmed();
                selected_cus_balance = query.value(3).toString().trimmed();
                selected_cus_balance_type = query.value(4).toString().trimmed();

                ui->label_name_balance_amt->setText("Rs "+selected_cus_balance);

                if(selected_cus_balance_type.toInt() == 0)
                {
                    ui->label_name_balance_title->setText("Op.Advance:");
                }

                if(selected_cus_balance_type.toInt() == 1)
                {
                    ui->label_name_balance_title->setText("Op.Pending:");
                }

                print_supplier_report();

            }
        }
    }
}

void Report::print_supplier_report()
{

    QSqlQuery date_qur;
    QStringList lst_day_no;
    if(databaseObj->selectQuery("select day_no from day_master  where open_date between '"+ui->dateEdit_from_supplier->date().toString("dd-MM-yyyy")+"' and '"+ui->dateEdit_to_supplier->date().toString("dd-MM-yyyy")+"' and status='0'",date_qur))
    {
        if(date_qur.next())
        {
            lst_day_no << date_qur.value(0).toString().trimmed();
            while(date_qur.next())
            {
                lst_day_no << date_qur.value(0).toString().trimmed();
            }

        }
    }
    if(lst_day_no.size() > 0)
    {
        //! //!
        QSqlQuery supplier_qur;

        QString bat_type,bat_num;
        qDebug()<<"selected_vehicle_type ===>>>"<<selected_vehicle_type;
        //        if( selected_vehicle_type.contains("company",Qt::CaseInsensitive))
        //            bat_type = "0";
        //        if( selected_vehicle_type.contains("other",Qt::CaseInsensitive))
        //            bat_type = "1";
        //        if( selected_vehicle_type.contains("van",Qt::CaseInsensitive))
        //            bat_type = "2";

        CPrinter print;
        print.setFontType(CPrinter::eFontType_font2);

        print.addData("Supplier Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData(ui->label_name_balance_title->text().trimmed()+ui->label_name_balance_amt->text().trimmed(),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData("   Date    Supply    Paid     Balance",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


        float supplier_husk,supplier_amt = 0;
        for(int i=0;i<lst_day_no.size();i++)
        {
            if(databaseObj->selectQuery("select day_master.open_date,vehicle_no,cus_name,(inward_bale),(inward_hush),paid,balance,balance_type from transaction_master inner join day_master on transaction_master.day_no = day_master.day_no where cus_name='"+selected_cus_name+"' and batch_type='"+selected_vehicle_type+"' and vehicle_no='"+selected_vehicle_number+"' and is_payment='0' and transaction_master.day_no='"+lst_day_no.at(i)+"'",supplier_qur))
            {
                if(supplier_qur.next())
                {
                    QString balance_name = "";
                    QString str_supplier_husk,str_supplier_amt;
                    if(supplier_qur.value(7).toString().trimmed().toInt() == 0)
                        balance_name = "+";
                    if(supplier_qur.value(7).toString().trimmed().toInt() == 1)
                        balance_name = "-";

                    str_supplier_husk = supplier_qur.value(4).toString().trimmed();
                    str_supplier_amt = supplier_qur.value(5).toString().trimmed();
                    QString print_data = supplier_qur.value(0).toString().trimmed().leftJustified(10,' ',true)+" "+str_supplier_husk.trimmed().rightJustified(7,' ',true)+" "+str_supplier_amt.trimmed().rightJustified(9,' ',true)+" "+supplier_qur.value(6).toString().trimmed().prepend(balance_name).rightJustified(8,' ',true);
                    qDebug()<<"suppiler print data ===>>>"<<print_data;




                    print.addData(print_data,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                    supplier_husk += str_supplier_husk.toFloat();
                    supplier_amt += str_supplier_amt.toFloat();

                    while(supplier_qur.next())
                    {
                        QString balance_name = "";
                        QString str_supplier_husk,str_supplier_amt;
                        if(supplier_qur.value(7).toString().trimmed().toInt() == 0)
                            balance_name = "+";
                        if(supplier_qur.value(7).toString().trimmed().toInt() == 1)
                            balance_name = "-";

                        str_supplier_husk = supplier_qur.value(4).toString().trimmed();
                        str_supplier_amt = supplier_qur.value(5).toString().trimmed();
                        QString print_data = supplier_qur.value(0).toString().trimmed().leftJustified(10,' ',true)+" "+str_supplier_husk.trimmed().rightJustified(7,' ',true)+" "+str_supplier_amt.trimmed().rightJustified(9,' ',true)+" "+supplier_qur.value(6).toString().trimmed().prepend(balance_name).rightJustified(8,' ',true);
                        qDebug()<<"suppiler print data ===>>>"<<print_data;

                        print.addData(print_data,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        supplier_husk += str_supplier_husk.toFloat();
                        supplier_amt += str_supplier_amt.toFloat();
                    }
                }
            }
            supplier_qur.clear();
            if(databaseObj->selectQuery("select day_master.open_date,vehicle_no,cus_name,(inward_bale),(inward_hush),paid,balance,balance_type from transaction_master inner join day_master on transaction_master.day_no = day_master.day_no where cus_name='"+selected_cus_name+"' and batch_type='"+selected_vehicle_type+"' and vehicle_no='"+selected_vehicle_number+"' and is_payment='1' and transaction_master.day_no='"+lst_day_no.at(i)+"'",supplier_qur))
            {
                if(supplier_qur.next())
                {
                    QString balance_name = "";
                    QString str_supplier_husk,str_supplier_amt;
                    if(supplier_qur.value(7).toString().trimmed().toInt() == 0)
                        balance_name = "+";
                    if(supplier_qur.value(7).toString().trimmed().toInt() == 1)
                        balance_name = "-";

                    str_supplier_husk = supplier_qur.value(4).toString().trimmed();
                    str_supplier_amt = supplier_qur.value(5).toString().trimmed();
                    QString print_data = supplier_qur.value(0).toString().trimmed().leftJustified(10,' ',true)+" "+str_supplier_husk.trimmed().rightJustified(7,' ',true)+" "+str_supplier_amt.trimmed().rightJustified(9,' ',true)+" "+supplier_qur.value(6).toString().trimmed().prepend(balance_name).rightJustified(8,' ',true);
                    qDebug()<<"suppiler print data ===>>>"<<print_data;

                    print.addData(print_data,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                    supplier_husk += str_supplier_husk.toFloat();
                    supplier_amt += str_supplier_amt.toFloat();
                }

                while(supplier_qur.next())
                {
                    QString balance_name = "";
                    QString str_supplier_husk,str_supplier_amt;
                    if(supplier_qur.value(7).toString().trimmed().toInt() == 0)
                        balance_name = "+";
                    if(supplier_qur.value(7).toString().trimmed().toInt() == 1)
                        balance_name = "-";

                    str_supplier_husk = supplier_qur.value(4).toString().trimmed();
                    str_supplier_amt = supplier_qur.value(5).toString().trimmed();
                    QString print_data = supplier_qur.value(0).toString().trimmed().leftJustified(10,' ',true)+" "+str_supplier_husk.trimmed().rightJustified(7,' ',true)+" "+str_supplier_amt.trimmed().rightJustified(9,' ',true)+" "+supplier_qur.value(6).toString().trimmed().prepend(balance_name).rightJustified(8,' ',true);
                    qDebug()<<"suppiler print data ===>>>"<<print_data;

                    print.addData(print_data,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                    supplier_husk += str_supplier_husk.toFloat();
                    supplier_amt += str_supplier_amt.toFloat();
                }
            }
        }

        print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
        print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

        if(print.print(false,false))
        {

        }
        call_Report();
//        if(supplier_husk > 0)
//        {
//            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
//            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
//            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
//            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

//            if(print.print(false,false))
//            {

//            }
//            call_Report();
//        }
//        else
//        {
//            //! msg
//        }



    }
    else
    {
        //! no result for supplier
    }
    return true;

}

void Report::on_pushButton_bale_clicked()
{

    QString last_date = QString::number(QDate::currentDate().daysInMonth());

    QString from_date = "01-"+QString::number(QDate::currentDate().month()).rightJustified(2,'0')+"-"+QString::number(QDate::currentDate().year());
    QString to_date = last_date+"-"+QString::number(QDate::currentDate().month()).rightJustified(2,'0')+"-"+QString::number(QDate::currentDate().year());

    QSqlQuery month_report_qur;
    int nif_count = 0;
    int vcp_count = 0;
    if(databaseObj->selectQuery("select day_master.day_no,day_master.open_date,bale_produced,bale_dispatched,bale_dispatched_to,closing_balance from day_close inner join day_master on day_master.day_no = day_close.day_no where day_close.day_no in (select day_no from day_master  where open_date between '"+from_date+"' and '"+to_date+"' and status='0') group by day_close.day_no",month_report_qur))
    {
        if(month_report_qur.next())
        {
#if(SDK75)
            CPrinter print;
            print.setFontType(CPrinter::eFontType_font2);

            print.addData("Batch Production/Supply Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Day No       :"+month_report_qur.value(0).toString().trimmed(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Day Date     :"+month_report_qur.value(1).toString().trimmed(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Bale Produced:"+month_report_qur.value(2).toString().trimmed()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Bale Dispatch:"+month_report_qur.value(3).toString().trimmed()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            QString dispatched_to = month_report_qur.value(4).toString().trimmed();
            if(dispatched_to.contains("nif",Qt::CaseInsensitive))
                nif_count+=1;
            if(dispatched_to.contains("vcp",Qt::CaseInsensitive))
                vcp_count+=1;

            print.addData("Dispatch To  :"+dispatched_to,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Closing Bale :"+month_report_qur.value(5).toString().trimmed()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

            while(month_report_qur.next())
            {
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Day No       :"+month_report_qur.value(0).toString().trimmed(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Day Date     :"+month_report_qur.value(1).toString().trimmed(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Bale Produced:"+month_report_qur.value(2).toString().trimmed()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Bale Dispatch:"+month_report_qur.value(3).toString().trimmed()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                QString dispatched_to = month_report_qur.value(4).toString().trimmed();
                if(dispatched_to.contains("nif",Qt::CaseInsensitive))
                    nif_count+=1;
                if(dispatched_to.contains("vcp",Qt::CaseInsensitive))
                    vcp_count+=1;

                print.addData("Dispatch To  :"+dispatched_to,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Closing Bale :"+month_report_qur.value(5).toString().trimmed()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }

            if(nif_count > 0)
            {
                print.addData("Total Loads NIF:"+QString::number(nif_count),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }
            if(vcp_count > 0)
            {
                print.addData("Total Loads VCP:"+QString::number(vcp_count),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }

            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            if(print.print(false,false))
            {
            }
#endif

        }
    }
}

void Report::on_comboBox_batch_currentTextChanged(const QString &arg1)
{
    qDebug()<<"on_comboBox_batch_currentIndexChanged ===>>>";
    ui->label_purchase->clear();
    ui->label_husk_bale->clear();
    ui->label_bale->clear();
    ui->label_purchase->clear();
    ui->label_gain_lose->clear();
}

void Report::on_lineEdit_batch_supplier_returnPressed()
{

}

void Report::on_lineEdit_day_no_returnPressed()
{
#if(SDK75)
    QSqlQuery day_details;
    if(databaseObj->selectQuery("SELECT day_no,status,open_date,open_time,close_date,close_time,open_bull_reading,open_gen_reading,open_eb_reading,open_diesel_reading,opening_bale_balance FROM day_master WHERE id_day= (SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",day_details))
    {
        //#if(SDK75)
        if(day_details.next())
        {
            CPrinter print;
            print.setFontType(CPrinter::eFontType_font2);

            print.addData("Day Close Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);

            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Day No    :"+day_details.value(0).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Open Date :"+day_details.value(2).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Open Time :"+day_details.value(3).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Close Date:"+day_details.value(4).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Close Time:"+day_details.value(5).toString(),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

            day_details.clear();
            QStringList lst_aval_batch_type;
            QString total_husk;
            if(databaseObj->selectQuery("select transaction_master.batch_type from transaction_master where transaction_master.day_no=(SELECT day_no FROM day_master WHERE id_day=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')) group by transaction_master.batch_type",day_details))
            {
                if(day_details.next())
                {
                    lst_aval_batch_type << day_details.value(0).toString().trimmed();
                    while(day_details.next())
                    {
                        lst_aval_batch_type << day_details.value(0).toString().trimmed();
                    }
                    qDebug()<<"avaliable batched ===>>>"<<lst_aval_batch_type;
                }
            }
            if(lst_aval_batch_type.size() > 0)
            {
                print.addData("Purchase Details",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("SNO  Vh   Load  CFT    HUSK    EXCESS",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                float tmp_total = 0;
                print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                for(int i=0;i<lst_aval_batch_type.size();i++)
                {
                    day_details.clear();
                    if(databaseObj->selectQuery("select count(transaction_master.batch_type),sum(transaction_master.inward_bale),sum(transaction_master.inward_hush),sum(transaction_master.excess_amt),sum(transaction_master.inward_hush)*(select configuration_master.auto_rate_of_husk from configuration_master),sum(transaction_master.vkms) from transaction_master where transaction_master.batch_type='"+lst_aval_batch_type.at(i)+"'",day_details))
                    {
                        if(day_details.next())
                        {
                            QString batch_name,to_print;
                            if(lst_aval_batch_type.at(i).toInt() == 0)
                                batch_name = "Comp";
                            if(lst_aval_batch_type.at(i).toInt() == 1)
                                batch_name = "Auto";
                            if(lst_aval_batch_type.at(i).toInt() == 2)
                                batch_name = "Van ";

                            to_print = QString::number(i+1).rightJustified(3,'0')+" "+batch_name+" "+day_details.value(0).toString().trimmed().rightJustified(4,' ')+" "+day_details.value(1).toString().trimmed().rightJustified(4,' ')+" "+day_details.value(3).toString().trimmed().rightJustified(6,' ')+" "+day_details.value(4).toString().trimmed().rightJustified(7,' ')+" "+QString::number(day_details.value(5).toString().trimmed().toFloat(),'f',2).rightJustified(9,' ');
//                            to_print = QString::number(i+1).rightJustified(3,'0')+batch_name
                            tmp_total+=day_details.value(2).toString().trimmed().toFloat();

                            qDebug()<<"tmp_total ===>>>"<<tmp_total;
                            qDebug()<<"to_print ===>>>"<<to_print;

                            print.addData(to_print,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        }
                    }
                }

                float total_husk = tmp_total;
                print.addData("Husk Purchased: "+QString::number(tmp_total,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);

                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Cash Flow",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                print.addData("SNO  vh     Qty   Rate    Amt    Kms ",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                tmp_total = 0;
                for(int i=0;i<lst_aval_batch_type.size();i++)
                {

                    QString rate_of_husk;
                    day_details.clear();
                    if(databaseObj->selectQuery("select count(transaction_master.batch_type),sum(transaction_master.inward_bale),sum(transaction_master.inward_hush),sum(transaction_master.excess_amt),sum(transaction_master.inward_hush)*(select configuration_master.auto_rate_of_husk from configuration_master),sum(transaction_master.vkms) from transaction_master where transaction_master.batch_type='"+lst_aval_batch_type.at(i)+"'",day_details))
                    {
                        if(day_details.next())
                        {
                            QString batch_name,to_print,batch_name_rate;
                            if(lst_aval_batch_type.at(i).toInt() == 0){
                                batch_name = "Comp";
                                batch_name_rate = "rate_of_husk";
                            }
                            if(lst_aval_batch_type.at(i).toInt() == 1){
                                batch_name = "Auto";
                                batch_name_rate = "auto_rate_of_husk";
                            }
                            if(lst_aval_batch_type.at(i).toInt() == 2){
                                batch_name = "Van";
                                batch_name_rate = "van_rate_of_husk";
                            }

                            QSqlQuery husk_rate;
                            if(databaseObj->selectQuery("select configuration_master."+batch_name_rate+" from configuration_master",husk_rate))
                            {
                                if(husk_rate.next())
                                {
                                    rate_of_husk = husk_rate.value(0).toString().trimmed();
                                }
                            }

                            to_print = QString::number(i).rightJustified(3,'0')+" "+batch_name+" "+day_details.value(3).toString().trimmed().rightJustified(6,' ')+" "+rate_of_husk+" "+day_details.value(4).toString().trimmed().rightJustified(9,' ');
                            tmp_total+=day_details.value(4).toString().trimmed().toFloat();

                            qDebug()<<"tmp_total ===>>>"<<tmp_total;
                            qDebug()<<"to_print ===>>>"<<to_print;

                            print.addData(to_print,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                        }
                    }
                }
                float total_husk_amount = tmp_total;
                print.addData("Total Cash   : "+QString::number(tmp_total,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("Avg Hush Rate: "+QString::number(total_husk_amount/total_husk,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);



                QSqlQuery expense_qur;
                QStringList lst_expense_name,lst_expense_bill_no,lst_expense_amount,lst_expense_user_id;
                if(databaseObj->selectQuery("select * from expense_transaction where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",expense_qur))
                {
                    if(expense_qur.next())
                    {
                        lst_expense_name << expense_qur.value(2).toString().trimmed();
                        lst_expense_bill_no << expense_qur.value(3).toString().trimmed();
                        lst_expense_amount << expense_qur.value(4).toString().trimmed();
                        lst_expense_user_id << expense_qur.value(6).toString().trimmed();
                        while(expense_qur.next())
                        {
                            lst_expense_name << expense_qur.value(2).toString().trimmed();
                            lst_expense_bill_no << expense_qur.value(3).toString().trimmed();
                            lst_expense_amount << expense_qur.value(4).toString().trimmed();
                            lst_expense_user_id << expense_qur.value(6).toString().trimmed();
                        }
                    }
                }

                if(lst_expense_name.size() > 0)
                {
                    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                    print.addData("Expense",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                    print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                    print.addData("SNO      Expense Name        Amount",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                    float total_exp_amt = 0;
                    for(int i=0;i<lst_expense_name.size();i++)
                    {
                        QString prt_text = QString::number(i+1).rightJustified(2,' ')+" "+lst_expense_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_expense_amount.at(i).toFloat(),'f',2).rightJustified(15,' ');
                        qDebug()<<"expense data ===>>>"<<prt_text;
                        print.addData(prt_text,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        total_exp_amt += lst_expense_amount.at(i).toFloat();
                    }
                    print.addData("Total Expense: "+QString::number(total_exp_amt,'f',2),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                }


                QSqlQuery husk_stock;
                //! auto batch

                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Stock Status Report",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);


                husk_stock.clear();
                if(databaseObj->selectQuery("select * from production_batch_order where batch_type='auto'",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        print.addData("Auto Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        while(husk_stock.next())
                        {
                            print.addData("Auto Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                    }
                }

                husk_stock.clear();
                if(databaseObj->selectQuery("select * from production_batch_order where batch_type='company'",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        print.addData("Company Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        while(husk_stock.next())
                        {
                            print.addData("Company Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                    }
                }

                husk_stock.clear();
                if(databaseObj->selectQuery("select * from production_batch_order where batch_type='van'",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        print.addData("Van Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        while(husk_stock.next())
                        {
                            print.addData("Van Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                    }
                }
                QString husk_available_production;
                husk_stock.clear();
                if(databaseObj->selectQuery("select sum(husk_available) from production_batch_order",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        husk_available_production = husk_stock.value(0).toString().trimmed();
                        //                        print.addData("Auto Batch "+husk_stock.value(2).toString().rightJustified(3,'0')+": "+husk_stock.value(3).toString()+" Nos",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                    }
                }

                husk_stock.clear();
                QString closing_bale,closing_husk;
                if(databaseObj->selectQuery("select closing_bale_balance from day_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",husk_stock))
                {
                    if(husk_stock.next())
                    {
                        closing_bale = husk_stock.value(0).toString().trimmed();
                        closing_husk = QString::number(closing_bale.toFloat()*Home_ScreenObj->HP_bale.toFloat(),'f',2);
                    }
                }

                float total_husk_count = husk_available_production.toFloat()+closing_husk.toFloat();

                print.addData("Total No Of Husk: "+QString::number(total_husk_count,'f',2)+" Nos",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);



                QSqlQuery diesel_qur;

                QString initial_diesel_stock;
                diesel_qur.clear();
                if(databaseObj->selectQuery("select init_diesel_reading from configuration_master",diesel_qur))
                {
                    if(diesel_qur.next())
                    {
                        initial_diesel_stock = diesel_qur.value(0).toString().trimmed();
                    }
                }
                diesel_qur.clear();
                if(databaseObj->selectQuery("select * from diesel_usage where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"') and fill_type='1'",diesel_qur))
                {
                    if(diesel_qur.next())
                    {
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        print.addData("Diesel Consumption",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        diesel_qur.clear();
                        if(databaseObj->selectQuery("select * from diesel_usage where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"') and fill_type='1' group by vehicle_no",diesel_qur))
                        {
                            if(diesel_qur.next())
                            {
                                QString v_name = diesel_qur.value(1).toString().trimmed();
                                QString diff = get_difference(v_name);
                                qDebug()<<"diff ===>>>"<<diff;
                                if(diff.toInt() > 0)
                                {
                                    print.addData(v_name.toUpper().leftJustified(12,' ')+": "+diff ,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                                }
                            }
                        }

                        print.addData("Closing Stock: "+initial_diesel_stock+" lts",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        diesel_qur.clear();
                    }
                }


                QSqlQuery payables_qur;
                QString v_pay = "0";
                QStringList lst_v_no,lst_party_name,lst_amt;
                payables_qur.clear();
                if(databaseObj->selectQuery("select vehicle_no,cus_name,paid from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",payables_qur))
                {
                    if(payables_qur.next())
                    {
                        lst_v_no << payables_qur.value(0).toString().trimmed();
                        lst_party_name << payables_qur.value(1).toString().trimmed();
                        lst_amt << payables_qur.value(2).toString().trimmed();
                        while(payables_qur.next())
                        {
                            lst_v_no << payables_qur.value(0).toString().trimmed();
                            lst_party_name << payables_qur.value(1).toString().trimmed();
                            lst_amt << payables_qur.value(2).toString().trimmed();
                        }
                    }
                    if(lst_v_no.size() > 0)
                    {
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                        print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        print.addData("Vehicle No    Party Name       Amount",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

                        for(int i=0;i<lst_v_no.size();i++)
                        {
                            print.addData(lst_v_no.at(i).leftJustified(11,' ')+" "+lst_party_name.at(i).rightJustified(15,' ')+" "+QString::number(lst_amt.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                        payables_qur.clear();
                        if(databaseObj->selectQuery("select sum(paid) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",payables_qur))
                        {
                            if(payables_qur.next())
                            {
                                v_pay = payables_qur.value(0).toString().trimmed();
                            }
                        }
                    }
                }

                QSqlQuery bunk_qur;
                QString bunk_pay = "0";
                QStringList lst_bunk_name,lst_bunk_qty,lst_bunk_amount;
                if(databaseObj->selectQuery("select diesel_transaction.bunk_id,bunk_master.bunk_name,diesel_transaction.quantity,diesel_transaction.amount from diesel_transaction inner join bunk_master on diesel_transaction.bunk_id=bunk_master.id_bunk_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",bunk_qur))
                {
                    if(bunk_qur.next())
                    {
                        lst_bunk_name << bunk_qur.value(1).toString().trimmed();
                        lst_bunk_qty << bunk_qur.value(2).toString().trimmed();
                        lst_bunk_amount << bunk_qur.value(3).toString().trimmed();
                        while(bunk_qur.next())
                        {
                            lst_bunk_name << bunk_qur.value(1).toString().trimmed();
                            lst_bunk_qty << bunk_qur.value(2).toString().trimmed();
                            lst_bunk_amount << bunk_qur.value(3).toString().trimmed();
                        }
                    }


                    if(lst_bunk_name.size() > 0)
                    {

                        if(lst_v_no.size() == 0)
                        {
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }

                        for(int i=0;i<lst_bunk_name.size();i++)
                        {
                            print.addData("            "+lst_bunk_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_bunk_amount.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                        bunk_qur.clear();
                        if(databaseObj->selectQuery("select sum(diesel_transaction.amount) from diesel_transaction where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",bunk_qur))
                        {
                            if(bunk_qur.next())
                            {
                                bunk_pay = bunk_qur.value(0).toString().trimmed();
                            }
                        }
                    }
                }

                QSqlQuery emp_qur;
                QString emp_pay = "0";
                QStringList lst_emp_name,lst_emp_amount;
                if(databaseObj->selectQuery("select emp_name,paid_salary from employee_transaction where paid_salary IS NOT NULL and day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",emp_qur))
                {
                    if(emp_qur.next())
                    {
                        lst_emp_name << emp_qur.value(0).toString().trimmed();
                        lst_emp_amount << emp_qur.value(1).toString().trimmed();
                        while(emp_qur.next())
                        {
                            lst_emp_name << emp_qur.value(0).toString().trimmed();
                            lst_emp_amount << emp_qur.value(1).toString().trimmed();
                        }
                    }
                    if(lst_emp_name.size() > 0)
                    {

                        if( (lst_v_no.size() == 0) && (lst_bunk_name.size() == 0) )
                        {
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                            print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }

                        for(int i=0;i<lst_emp_name.size();i++)
                        {
                            print.addData("            "+lst_emp_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_emp_amount.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                        }
                        emp_qur.clear();
                        if(databaseObj->selectQuery("select sum(paid_salary) from employee_transaction where paid_salary IS NOT NULL and day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",emp_qur))
                        {
                            if(emp_qur.next())
                            {
                                emp_pay = emp_qur.value(0).toString().trimmed();
                            }
                        }
                    }
                }
                if( (lst_v_no.size() != 0) || (lst_bunk_name.size() != 0) || (lst_emp_name.size() != 0) )
                {
                    print.addData("Total Payables:Rs "+QString::number(v_pay.toFloat() + emp_pay.toFloat() + bunk_pay.toFloat(),'f',2 ),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                }

                //                QSqlQuery batch_supplier_qur;
                //                if(databaseObj->selectQuery("select vehicle_no,cus_name,count(vehicle_no),sum(inward_bale),sum(inward_hush) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"') group by cus_name",batch_supplier_qur))
                //                {
                //                    if(batch_supplier_qur.next())
                //                    {
                //                        QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ')+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ')+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed(),'f',2).rightJustified(6,' ')+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed(),'f',2).rightJustified(9,' ');
                //                        qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                //                        print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                //                        while(batch_supplier_qur.next())
                //                        {
                //                            QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ')+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ')+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed(),'f',2).rightJustified(6,' ')+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed(),'f',2).rightJustified(9,' ');
                //                            qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                //                            print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                //                        }
                //                        batch_supplier_qur.clear();
                //                        if(databaseObj->selectQuery("select sum(inward_bale),sum(inward_hush) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0' and day_no='"+QString::number(ui->lineEdit_day_no->text().trimmed().remove("Day",Qt::CaseInsensitive).toInt())+"')",batch_supplier_qur))
                //                        {
                //                            if(batch_supplier_qur.next())
                //                            {
                ////                                QString batch_supplier_details = batch_supplier_qur.value(0).toString().trimmed().leftJustified(10,' ')+" "+batch_supplier_qur.value(1).toString().trimmed().leftJustified(7,' ')+" "+batch_supplier_qur.value(2).toString().trimmed().rightJustified(2,' ')+" "+QString::number(batch_supplier_qur.value(3).toString().trimmed(),'f',2).rightJustified(6,' ')+" "+QString::number(batch_supplier_qur.value(4).toString().trimmed(),'f',2).rightJustified(9,' ');
                ////                                qDebug()<<"batch_supplier_details ===>>>"<<batch_supplier_details;
                //                                print.addData(batch_supplier_details,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                //                            }
                //                        }
                //                    }
                //                }



            }

            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            if(print.print(false,false))
            {

            }
            call_Report();

        }
    }
#endif
}

void Report::on_pushButton_stock_status_clicked()
{

}

void Report::on_pushButton_payable_clicked()
{
    QSqlQuery payables_qur;
    QString v_pay = "0";
    QStringList lst_v_no,lst_party_name,lst_amt;
    payables_qur.clear();
    CPrinter print;
    print.setFontType(CPrinter::eFontType_font2);
    if(databaseObj->selectQuery("select vehicle_no,cus_name,paid from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",payables_qur))
    {
        if(payables_qur.next())
        {
            lst_v_no << payables_qur.value(0).toString().trimmed();
            lst_party_name << payables_qur.value(1).toString().trimmed();
            lst_amt << payables_qur.value(2).toString().trimmed();
            while(payables_qur.next())
            {
                lst_v_no << payables_qur.value(0).toString().trimmed();
                lst_party_name << payables_qur.value(1).toString().trimmed();
                lst_amt << payables_qur.value(2).toString().trimmed();
            }
        }
        if(lst_v_no.size() > 0)
        {
            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
            print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            print.addData("Vehicle No    Party Name       Amount",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);

            for(int i=0;i<lst_v_no.size();i++)
            {
                print.addData(lst_v_no.at(i).leftJustified(11,' ')+" "+lst_party_name.at(i).rightJustified(15,' ')+" "+QString::number(lst_amt.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }
            payables_qur.clear();
            if(databaseObj->selectQuery("select sum(paid) from transaction_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",payables_qur))
            {
                if(payables_qur.next())
                {
                    v_pay = payables_qur.value(0).toString().trimmed();
                }
            }
        }
    }

    QSqlQuery bunk_qur;
    QString bunk_pay = "0";
    QStringList lst_bunk_name,lst_bunk_qty,lst_bunk_amount;
    if(databaseObj->selectQuery("select diesel_transaction.bunk_id,bunk_master.bunk_name,diesel_transaction.quantity,diesel_transaction.amount from diesel_transaction inner join bunk_master on diesel_transaction.bunk_id=bunk_master.id_bunk_master where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",bunk_qur))
    {
        if(bunk_qur.next())
        {
            lst_bunk_name << bunk_qur.value(1).toString().trimmed();
            lst_bunk_qty << bunk_qur.value(2).toString().trimmed();
            lst_bunk_amount << bunk_qur.value(3).toString().trimmed();
            while(bunk_qur.next())
            {
                lst_bunk_name << bunk_qur.value(1).toString().trimmed();
                lst_bunk_qty << bunk_qur.value(2).toString().trimmed();
                lst_bunk_amount << bunk_qur.value(3).toString().trimmed();
            }
        }


        if(lst_bunk_name.size() > 0)
        {

            if(lst_v_no.size() == 0)
            {
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }

            for(int i=0;i<lst_bunk_name.size();i++)
            {
                print.addData("            "+lst_bunk_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_bunk_amount.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }
            bunk_qur.clear();
            if(databaseObj->selectQuery("select sum(diesel_transaction.amount) from diesel_transaction where day_no=(SELECT MAX(id_day) FROM day_master where status='0')",bunk_qur))
            {
                if(bunk_qur.next())
                {
                    bunk_pay = bunk_qur.value(0).toString().trimmed();
                }
            }
        }
    }

    QSqlQuery emp_qur;
    QString emp_pay = "0";
    QStringList lst_emp_name,lst_emp_amount;
    if(databaseObj->selectQuery("select emp_name,paid_salary from employee_transaction where paid_salary IS NOT NULL and day_no=(SELECT MAX(id_day) FROM day_master where status='0')",emp_qur))
    {
        if(emp_qur.next())
        {
            lst_emp_name << emp_qur.value(0).toString().trimmed();
            lst_emp_amount << emp_qur.value(1).toString().trimmed();
            while(emp_qur.next())
            {
                lst_emp_name << emp_qur.value(0).toString().trimmed();
                lst_emp_amount << emp_qur.value(1).toString().trimmed();
            }
        }
        if(lst_emp_name.size() > 0)
        {

            if( (lst_v_no.size() == 0) && (lst_bunk_name.size() == 0) )
            {
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
                print.addData("Payables/Receivable",CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
                print.addData("--------------------------------------",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }

            for(int i=0;i<lst_emp_name.size();i++)
            {
                print.addData("            "+lst_emp_name.at(i).leftJustified(15,' ')+" "+QString::number(lst_emp_amount.at(i).rightJustified(10,' ').toFloat(),'f',2),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            }
            emp_qur.clear();
            if(databaseObj->selectQuery("select sum(paid_salary) from employee_transaction where paid_salary IS NOT NULL and day_no=(SELECT MAX(id_day) FROM day_master where status='0')",emp_qur))
            {
                if(emp_qur.next())
                {
                    emp_pay = emp_qur.value(0).toString().trimmed();
                }
            }
        }
    }
    if( (lst_v_no.size() != 0) || (lst_bunk_name.size() != 0) || (lst_emp_name.size() != 0) )
    {
        print.addData("Total Payables:Rs "+QString::number(v_pay.toFloat() + emp_pay.toFloat() + bunk_pay.toFloat(),'f',2 ),CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
    }
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    if(print.print(false,false))
    {

    }
    call_Report();
}

void Report::on_pushButton_diesel_clicked()
{

}
