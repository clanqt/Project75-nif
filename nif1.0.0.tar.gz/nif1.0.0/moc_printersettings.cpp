/****************************************************************************
** Meta object code from reading C++ file 'printersettings.h'
**
** Created: Fri Oct 26 19:58:58 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "printersettings.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'printersettings.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_PrinterSettings[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   16,   16,   16, 0x08,
      51,   16,   16,   16, 0x08,
      80,   16,   16,   16, 0x08,
     110,   16,   16,   16, 0x08,
     139,   16,   16,   16, 0x08,
     175,  169,   16,   16, 0x08,
     223,  169,   16,   16, 0x08,
     267,   16,   16,   16, 0x08,
     306,   16,   16,   16, 0x08,
     345,  337,   16,   16, 0x08,
     382,  337,   16,   16, 0x08,
     420,  337,   16,   16, 0x08,
     455,  337,   16,   16, 0x08,
     492,  337,   16,   16, 0x08,
     530,  337,   16,   16, 0x08,
     565,   16,   16,   16, 0x08,
     604,   16,   16,   16, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_PrinterSettings[] = {
    "PrinterSettings\0\0on_pushButton_font_type_clicked()\0"
    "on_pushButton_H_on_clicked()\0"
    "on_pushButton_H_off_clicked()\0"
    "on_pushButton_F_on_clicked()\0"
    "on_pushButton_F_off_clicked()\0index\0"
    "on_comboBox_heade_line_currentIndexChanged(int)\0"
    "on_comboBox_F_line_currentIndexChanged(int)\0"
    "on_pushButton_header_setting_clicked()\0"
    "on_pushButton_H_save_clicked()\0checked\0"
    "on_radioButton_H_small_clicked(bool)\0"
    "on_radioButton_H_medium_clicked(bool)\0"
    "on_radioButton_H_big_clicked(bool)\0"
    "on_radioButton_F_small_clicked(bool)\0"
    "on_radioButton_F_medium_clicked(bool)\0"
    "on_radioButton_F_big_clicked(bool)\0"
    "on_pushButton_footer_setting_clicked()\0"
    "on_pushButton_F_save_clicked()\0"
};

void PrinterSettings::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        PrinterSettings *_t = static_cast<PrinterSettings *>(_o);
        switch (_id) {
        case 0: _t->on_pushButton_font_type_clicked(); break;
        case 1: _t->on_pushButton_H_on_clicked(); break;
        case 2: _t->on_pushButton_H_off_clicked(); break;
        case 3: _t->on_pushButton_F_on_clicked(); break;
        case 4: _t->on_pushButton_F_off_clicked(); break;
        case 5: _t->on_comboBox_heade_line_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_comboBox_F_line_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_pushButton_header_setting_clicked(); break;
        case 8: _t->on_pushButton_H_save_clicked(); break;
        case 9: _t->on_radioButton_H_small_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_radioButton_H_medium_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->on_radioButton_H_big_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->on_radioButton_F_small_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->on_radioButton_F_medium_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->on_radioButton_F_big_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->on_pushButton_footer_setting_clicked(); break;
        case 16: _t->on_pushButton_F_save_clicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData PrinterSettings::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject PrinterSettings::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_PrinterSettings,
      qt_meta_data_PrinterSettings, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &PrinterSettings::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *PrinterSettings::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *PrinterSettings::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_PrinterSettings))
        return static_cast<void*>(const_cast< PrinterSettings*>(this));
    return QWidget::qt_metacast(_clname);
}

int PrinterSettings::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
