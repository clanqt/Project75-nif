#ifndef PAYMENT_H
#define PAYMENT_H

#include <QWidget>
#include <QCompleter>

namespace Ui {
class Payment;
}

class Payment : public QWidget
{
    Q_OBJECT

public:

    QCompleter *cmpter,*cmpter1,*cmpter2,*cmpter3,*cmpter4,*cmpter5;
    QStringList lst_customer_name,lst_customer_mobile,lst_vehicle_number,lst_broker_name;
    QString selected_cus_name,selected_cus_mobile,selected_cus_balance,selected_cus_balance_type,selected_cus_id,final_total;
    QString selected_vehicle_number_id,selected_vehicle_number,selected_vehicle_name,selected_vehicle_type,selected_vehicle_type_name,selected_vehicle_length,selected_vehicle_length_inch,selected_vehicle_width,selected_vehicle_width_inch,selected_vehicle_height,selected_vehicle_height_inche;
    QString final_bal_type;

    QString selected_bunk_name,selected_bunk_balance,selected_bunk_balance_type,final_deisel_amt;
    QString selected_labour_name,selected_labour_type,selected_labour_balance,selected_labour_balance_type,final_labour_amt;

    QStringList lst_bunk_name,lst_emp_name;

    void call_Payment();

    void show_screen(int scr);

    void keyPressEvent(QKeyEvent *ke);

    QString StringRightAlign(QString Data,int len);

    QString StringAlign(QString Data,int len);

    explicit Payment(QWidget *parent = 0);
    ~Payment();

private slots:
    void on_pushButton_Husk_clicked();

    void on_lineEdit_vehicle_number_returnPressed();

    void on_lineEdit_paid_amt_returnPressed();

    void on_pushButton_husk_payment_save_clicked();

    void on_pushButton_other_clicked();

    void on_lineEdit_diesel_bunk_name_returnPressed();

    void on_lineEdit_diesel_amount_returnPressed();

    void on_pushButton_payment_diesel_save_clicked();

    void on_pushButton_Diesel_clicked();

    void on_lineEdit_labour_bunk_name_returnPressed();

    void on_lineEdit_labour_amount_returnPressed();

    void on_pushButton_payment_labour_save_clicked();

    void on_pushButton_labour_clicked();

    void on_lineEdit_labour_name_returnPressed();

    void on_lineEdit_customer_returnPressed();

    void on_pushButton_staff_clicked();

private:
    Ui::Payment *ui;
};

#endif // PAYMENT_H
