#include "employeemaster.h"
#include "ui_employeemaster.h"

#include <global.h>
using namespace Global;

EmployeeMaster::EmployeeMaster(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EmployeeMaster)
{
    ui->setupUi(this);

#if(NativeCompile)
    setParent(mdi,Qt::Dialog);
#endif

#if(SDK75)
    setParent(MdiArea,Qt::Dialog);
#endif
    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);

    scroll = new QScrollArea(ui->groupBox);
    scroll->setWidget(ui->gridLayoutWidget);
    scroll->move(0,30);
    scroll->setFixedSize(320,150);//160
    scroll->setFocusPolicy(Qt::NoFocus);
    scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

}

EmployeeMaster::~EmployeeMaster()
{
    delete ui;
}

void EmployeeMaster::call_employee_master()
{
    ui->lineEdit_charges->clear();
    ui->lineEdit_emp_contact->clear();
    ui->lineEdit_emp_name->clear();
    ui->lineEdit_op_balance->clear();
    ui->lineEdit_rate_pe_hour->clear();
    ui->lineEdit_target->clear();

    ui->comboBox_gender->installEventFilter(this);
    ui->comboBox_type->installEventFilter(this);
    ui->radioButton_pending->installEventFilter(this);
    ui->radioButton_advance->installEventFilter(this);


    ui->comboBox_gender->setCurrentIndex(0);
    ui->comboBox_type->setCurrentIndex(0);
    ui->lineEdit_emp_name->setFocus();
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_ALPHABETS);
#endif

}

void EmployeeMaster::keyPressEvent(QKeyEvent *ke)
{
    if(ke->key()== Qt::Key_Escape)
    {
        this->close();
        Master_Config_MenuObj->call_Master_Config_Menu();
        Master_Config_MenuObj->show();
    }
//    if(ke->key()== 15)
//    {
//        qDebug()<<"Tab keyPressEvent ===>>>";
//    }
}

bool EmployeeMaster::eventFilter(QObject *target, QEvent *event)
{
    QKeyEvent *key = static_cast <QKeyEvent*> (event);


//    if(event->type() == QEvent::KeyPress)
//    {
//        if(key->key() == Qt::Key_Tab)
//        {
//            qDebug()<<"Tab pressed ===>>>";
//            return true;
//        }
//    }

    if(target == ui->comboBox_gender)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->comboBox_gender->hasFocus())
                {
                    ui->comboBox_type->setFocus();
                    return true;
                }
            }
        }
    }
    else if(target == ui->comboBox_type)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->comboBox_type->hasFocus())
                {
                    ui->lineEdit_rate_pe_hour->setFocus();
                    return true;
                }
            }
        }
    }
    else if(target == ui->radioButton_pending)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->radioButton_pending->hasFocus())
                {
                    ui->radioButton_pending->setChecked(true);
                    ui->radioButton_advance->setChecked(false);

                    ui->pushButton_purchase_save->setFocus();
                    return true;
                }
            }
        }
    }
    else if(target == ui->radioButton_advance)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->radioButton_advance->hasFocus())
                {
                    ui->radioButton_advance->setChecked(true);
                    ui->radioButton_pending->setChecked(false);

                    ui->pushButton_purchase_save->setFocus();
                    return true;
                }
            }
        }
    }

    else
    {
        return false;
    }

    return false;
}

void EmployeeMaster::on_lineEdit_emp_name_returnPressed()
{
    if(!ui->lineEdit_emp_name->text().isEmpty())
    {
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
        ui->lineEdit_emp_contact->setFocus();
    }
}

void EmployeeMaster::on_lineEdit_emp_contact_returnPressed()
{
    if(!ui->lineEdit_emp_contact->text().isEmpty())
    {
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
        ui->comboBox_gender->setFocus();
    }
}

void EmployeeMaster::on_lineEdit_rate_pe_hour_returnPressed()
{
    if(!ui->lineEdit_rate_pe_hour->text().isEmpty())
    {
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
        ui->lineEdit_target->setFocus();
    }
}

void EmployeeMaster::on_lineEdit_target_returnPressed()
{
    if(!ui->lineEdit_target->text().isEmpty())
    {
        if(ui->comboBox_type->currentText().contains("labour",Qt::CaseInsensitive))
        {
            if(ui->lineEdit_target->text().toFloat() > 0)
            {
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
                ui->lineEdit_charges->setFocus();
                return;
            }

        }
    }
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
    ui->lineEdit_charges->setFocus();
}

void EmployeeMaster::on_lineEdit_charges_returnPressed()
{
    if(!ui->lineEdit_charges->text().isEmpty())
    {

        if(ui->comboBox_type->currentText().contains("labour",Qt::CaseInsensitive))
        {
            if(ui->lineEdit_charges->text().toFloat() > 0)
            {
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
                ui->lineEdit_op_balance->setFocus();
                return;
            }
        }
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
        ui->lineEdit_op_balance->setFocus();
    }
}

void EmployeeMaster::on_lineEdit_op_balance_returnPressed()
{
    if(!ui->lineEdit_op_balance->text().isEmpty())
    {
#if(SDK75)
        g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif
        ui->radioButton_pending->setFocus();
    }
}

void EmployeeMaster::on_pushButton_purchase_save_clicked()
{
    if((!ui->lineEdit_emp_name->text().isEmpty()) &&
            (!ui->lineEdit_emp_contact->text().isEmpty()) &&
            (!ui->lineEdit_rate_pe_hour->text().isEmpty()) &&
            (!ui->lineEdit_target->text().isEmpty()) &&
            (!ui->lineEdit_charges->text().isEmpty()) &&
            (!ui->lineEdit_op_balance->text().isEmpty()))
    {

        qDebug()<<"lineEdit_emp_name ===>>>"<< ui->lineEdit_emp_name->text();
        qDebug()<<"lineEdit_emp_contact ===>>>"<< ui->lineEdit_emp_contact->text();
        qDebug()<<"lineEdit_rate_pe_hour ===>>>"<< ui->lineEdit_rate_pe_hour->text();
        qDebug()<<"lineEdit_target ===>>>"<< ui->lineEdit_target->text();
        qDebug()<<"lineEdit_charges ===>>>"<< ui->lineEdit_charges->text();
        qDebug()<<"lineEdit_op_balance ===>>>"<< ui->lineEdit_op_balance->text();

        QString balance_type;
        if(ui->radioButton_advance->isChecked())
        {
            balance_type = "0";
        }
        else if(ui->radioButton_pending->isChecked())
        {
            balance_type = "1";
        }
        else
        {
            balance_type = "1";
        }
        QString balance_name = "emp_balance";
        if(ui->comboBox_type->currentText().contains("labour",Qt::CaseInsensitive))
        {
            balance_name = "emp_balance_bale_rate";
        }
        else
        {
            balance_name = "emp_balance";
        }
        if(databaseObj->executeCommand("insert into employee_master (emp_name,emp_contact,emp_gender,emp_type,daily_wages,emp_target,emp_target_charge,"+balance_name+",emp_balance_type) values ('"+ui->lineEdit_emp_name->text().trimmed()+"','"+ui->lineEdit_emp_contact->text().trimmed()+"','"+ui->comboBox_gender->currentText().trimmed()+"','"+ui->comboBox_type->currentText().trimmed()+"','"+ui->lineEdit_rate_pe_hour->text().trimmed()+"','"+ui->lineEdit_target->text().trimmed()+"','"+ui->lineEdit_charges->text().trimmed()+"','"+ui->lineEdit_op_balance->text().trimmed()+"','"+balance_type+"')"))
        {
            qDebug()<<"data saved in employee_master ===>>>";
            call_employee_master();
        }
    }
}
