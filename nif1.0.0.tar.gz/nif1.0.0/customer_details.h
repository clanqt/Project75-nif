#ifndef CUSTOMER_DETAILS_H
#define CUSTOMER_DETAILS_H

#include <QWidget>

namespace Ui {
class Customer_Details;
}

class Customer_Details : public QWidget
{
    Q_OBJECT

public:


    QString payable_amt,paid_amt,balance,balance_type;

    QString StringRightAlign(QString Data,int len);

    QString StringAlign(QString Data,int len);


    void call_Customer_Details();

    void save_transaction();

//    bool eventFilter(QObject *target, QEvent *event);

    void keyPressEvent(QKeyEvent *ke);

    explicit Customer_Details(QWidget *parent = 0);
    ~Customer_Details();

private slots:
    void on_lineEdit_Excess_returnPressed();

    void on_lineEdit_paid_returnPressed();

    void on_pushButton_print_clicked();

    void on_lineEdit_Excess_textEdited(const QString &arg1);

private:
    Ui::Customer_Details *ui;
};

#endif // CUSTOMER_DETAILS_H
