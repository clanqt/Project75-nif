#include "day_close.h"
#include "ui_day_close.h"

#include <QMessageBox>

#include <global.h>
using namespace Global;

Day_Close::Day_Close(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Day_Close)
{
    ui->setupUi(this);

#if(NativeCompile)
    setParent(mdi,Qt::Dialog);
#endif

#if(SDK75)
    setParent(MdiArea,Qt::Dialog);
#endif
    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);

}

Day_Close::~Day_Close()
{
    delete ui;
}

void Day_Close::call_Day_Close()
{
    ui->lineEdit_op_bale->clear();
    ui->lineEdit_bale_dispatched->clear();
    ui->lineEdit_bale_produced->clear();
    ui->lineEdit_closing_bale->clear();

    ui->radioButton_nif->installEventFilter(this);
    ui->radioButton_vcp->installEventFilter(this);

    ui->pushButton_close->setEnabled(false);

    after_dispatch.clear();
    before_dispatch.clear();

    lst_batch_type.clear();
    lst_batch_no.clear();
    lst_husk_available.clear();
    lst_husk_to_bale.clear();

    QSqlQuery query;
    if(databaseObj->selectQuery("select * from production_batch_order",query))
    {
        if(query.next())
        {
            lst_batch_type << query.value(1).toString().trimmed();
            lst_batch_no << query.value(2).toString().trimmed();
            lst_husk_available << query.value(3).toString().trimmed();
            lst_husk_to_bale << QString::number(query.value(3).toString().trimmed().toFloat()/Home_ScreenObj->HP_bale.toFloat());
            while(query.next())
            {
                lst_batch_type << query.value(1).toString().trimmed();
                lst_batch_no << query.value(2).toString().trimmed();
                lst_husk_available << query.value(3).toString().trimmed();
                lst_husk_to_bale << QString::number(query.value(3).toString().trimmed().toFloat()/Home_ScreenObj->HP_bale.toFloat());
            }
        }
        if(lst_batch_no.size() > 0)
        {
            batch_type = lst_batch_no.at(0);
            batch_type = lst_batch_type.at(0);
            husk_available = lst_husk_available.at(0);
        }
        qDebug()<<"lst_batch_type ===>>>"<<lst_batch_type;
        qDebug()<<"lst_batch_no ===>>>"<<lst_batch_no;
        qDebug()<<"lst_husk_available ===>>>"<<lst_husk_available;
        qDebug()<<"lst_husk_available ===>>>"<<lst_husk_to_bale;



    }


    query.clear();
    if(databaseObj->selectQuery("select sum(husk_available) from production_batch_order",query))
    {
        if(query.next())
        {
            total_husk_available = query.value(0).toString().trimmed();

            total_bale_estimated = QString::number(total_husk_available.toFloat()/Home_ScreenObj->HP_bale.toFloat(),'f',2);
        }

        qDebug()<<"total_husk_available ===>>>"<<total_husk_available;
        qDebug()<<"total_bale_estimated ===>>>"<<total_bale_estimated;
    }

    qDebug()<<"gstrday_open_bale ===>>>"<<gstrday_open_bale;
    ui->lineEdit_op_bale->setText(gstrday_open_bale);

#if(SDK75)
                g_ccmainObj->setKeypadMode(eKeypadMode_NUMERIC);
#endif

    ui->lineEdit_bale_produced->setFocus();

}

void Day_Close::keyPressEvent(QKeyEvent *ke)
{
    if(ke->key()== Qt::Key_Escape)
    {
        this->close();
        menuObj->call_menu();
        menuObj->show();
    }
}

bool Day_Close::eventFilter(QObject *target, QEvent *event)
{
    QKeyEvent *key = static_cast <QKeyEvent*> (event);

    if(target == ui->radioButton_nif)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->radioButton_nif->hasFocus())
                {
                    ui->radioButton_nif->setChecked(true);
                    ui->radioButton_vcp->setChecked(false);
                    ui->pushButton_close->setEnabled(true);

                    //                    before_dispatch = QString::number(ui->lineEdit_op_bale->text().toFloat() + ui->lineEdit_bale_produced->text().toFloat());
                    //                    after_dispatch = before_dispatch

                    ui->lineEdit_bale_dispatched->setFocus();

                    return true;
                }
            }
        }
    }
    else if(target == ui->radioButton_vcp)
    {
        if(event->type() == QEvent::KeyPress)
        {
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter)
            {
                if(ui->radioButton_vcp->hasFocus())
                {
                    ui->radioButton_vcp->setChecked(true);
                    ui->radioButton_nif->setChecked(false);
                    ui->pushButton_close->setEnabled(true);




                    ui->lineEdit_bale_dispatched->setFocus();

                    return true;
                }
            }
        }
    }
    else
    {
        return false;
    }
    return false;
}

void Day_Close::on_lineEdit_bale_produced_returnPressed()
{
    if(ui->lineEdit_bale_produced->text().toInt() > 0)
    {
        before_dispatch = QString::number(ui->lineEdit_op_bale->text().toFloat() + ui->lineEdit_bale_produced->text().toFloat());
        ui->radioButton_nif->setFocus();
    }
}

void Day_Close::on_lineEdit_bale_dispatched_returnPressed()
{
    QString tmp_dispatch_qty = ui->lineEdit_bale_dispatched->text().trimmed();
    qDebug()<<"Day_Close test 1 ===>>>";
    use_next_batch = false;
    qDebug()<<"Day_Close test 2 ===>>>";
    if(ui->lineEdit_bale_dispatched->text().toInt() > 0)
    {
        qDebug()<<"Day_Close test 3 ===>>>";
        if(ui->lineEdit_bale_dispatched->text().toFloat() <= before_dispatch.toFloat())
        {
            bale_dispatched = ui->lineEdit_bale_dispatched->text().trimmed();

            after_dispatch = QString::number(before_dispatch.toFloat() - bale_dispatched.toFloat(),'f',2);
            ui->lineEdit_closing_bale->setText(after_dispatch);

            qDebug()<<"Day_Close test 4 ===>>>";
            ui->pushButton_close->setFocus();
//            for(int i=0;i<lst_batch_no.size();i++)
//            {
//                qDebug()<<"Day_Close test 5 ===>>>"<<i;
//                if(tmp_dispatch_qty >= lst_husk_available.at(i))
//                {
//                    qDebug()<<"Day_Close test 6 ===>>>";
//                    tmp_dispatch_qty = QString::number(tmp_dispatch_qty.toFloat() - lst_husk_available.at(i).toFloat(),'f',2);
//                    //! current batch need to closed

//                    batch_no = lst_batch_no.at(i);
//                    batch_type = lst_batch_type.at(i);
//                    husk_available = lst_husk_available.at(i);

//                    qDebug()<<"batch_type ===>>>"<<batch_type;
//                    qDebug()<<"batch_no ===>>>"<<batch_no;
//                    qDebug()<<"husk_available ===>>>"<<husk_available;

//                    if(lst_batch_type.at(i).contains("company",Qt::CaseInsensitive))
//                        company_or_other = 0;
//                    if(lst_batch_type.at(i).contains("auto",Qt::CaseInsensitive))
//                        company_or_other = 1;
//                    if(lst_batch_type.at(i).contains("van",Qt::CaseInsensitive))
//                        company_or_other = 2;


//                    this->hide();
//                    Batch_CloseObj->call_Batch_Close();
//                    Batch_CloseObj->show();

//                    qDebug()<<"after call ===>>>";


//                }

//                if(tmp_dispatch_qty <= lst_husk_available.at(i))
//                {
//                    qDebug()<<"Day_Close test 7 ===>>>";
//                    tmp_dispatch_qty = QString::number(lst_husk_available.at(i).toFloat() - tmp_dispatch_qty.toFloat(),'f',2);

//                }
//            }


        }
        else
        {
#if(NativeCompile)
            QMessageBox gMsg_box;
            QFont gFont;
            gFont.setFamily("DejaVu Sans Mono");
            gFont.setPointSize(12);
            gMsg_box.setFont(gFont);
            gMsg_box.setParent(this);

            if(gMsg_box.information(this, "Warning","Invalid Input!",QMessageBox::Ok) == QMessageBox::Ok)
            {
                ui->lineEdit_bale_dispatched->clear();
                ui->lineEdit_bale_dispatched->setFocus();
            }
#endif

#if(SDK75)
            int ret = g_ccmainObj->messagebox(this,"Status",eMessageType_Success,"",16,14);
            ui->lineEdit_bale_dispatched->clear();
            ui->lineEdit_bale_dispatched->setFocus();
#endif
        }
    }
}

void Day_Close::on_pushButton_close_clicked()
{
    if((ui->lineEdit_bale_dispatched->text().toInt() > 0) && (ui->lineEdit_bale_produced->text().toInt() > 0))
    {
//        Home_ScreenObj->close_day(this);
        closing_bale = ui->lineEdit_closing_bale->text();
        if(ui->radioButton_nif->isChecked())
            dispatched_to = "nif";
        if(ui->radioButton_vcp->isChecked())
            dispatched_to = "vcp";

        bale_produced = ui->lineEdit_bale_produced->text().trimmed();


        this->hide();
        Batch_CloseObj->call_Batch_Close();
        Batch_CloseObj->show();
    }
}
